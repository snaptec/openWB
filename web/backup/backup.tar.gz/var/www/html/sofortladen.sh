#!/bin/bash

begrenzungap1=$(($lastmaxap1 - $minimalstromstaerke))
begrenzungap1=$(($lastmaxap2 - $minimalstromstaerke))
begrenzungap1=$(($lastmaxap3 - $minimalstromstaerke))
llalt1=$(cat /var/www/html/openWB/ramdisk/llsoll)


if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
	runs/m$minimalstromstaerke.sh
	runs/s1$minimalstromstaerke.sh
	if [[ $debug == "1" ]]; then
               	echo starte sofort Ladeleistung mit lastmanagement mit Master $minimalstromstaerke und slave $minimalstromstaerke
       	fi
	exit 0
fi
if grep -q 1 "/var/www/html/openWB/ramdisk/ladestatus"; then							
	if (( $lla1 < 2 )) && (( $lla2 < 2 )) && (( $lla3 < 2 )); then
		if (( $llsoll1 < $begrenzungap1 )); then
			if (( llsoll1 < $sofortll )); then
				llneu1=$((llalt1 + 1 ))
				runs/s1$llneu1.sh
				runs/m$minimalstromstaerke.sh
				exit 0
			else
				exit 0
			fi
		else
			if ( $llsoll1 = $begrenzungap1 )); then
				exit 0
			fi
			llneu1=$((llalt1 -1 ))
			runs/s1$llneu1.sh
			runs/m$inimalstromstaerke.sh
			exit 0	
		fi
	fi
	if (( $llas11 < 2 )) && (( $llas12 < 2 )) && (( $llas13 < 2 )); then
		if (( $llsoll < $begrenzungap1 )); then
			if (( llsoll < $sofortll )); then
				llneu=$((llalt + 1 ))
				runs/m$llneu.sh
				runs/s1$minimalstromstaerke.sh
				exit 0
			else
				exit 0
			fi
		else
			if ( $llsoll = $begrenzungap1 )); then
				exit 0
			fi
			llneu=$((llalt -1 ))
			runs/m$llneu.sh
			runs/s1$inimalstromstaerke.sh
			exit 0	
		fi
	fi

fi




