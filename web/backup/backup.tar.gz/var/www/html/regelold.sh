#!/bin/bash
set -e
set -o pipefail
cd /var/www/html/openWB/
#config file einlesen
. openwb.conf
re='^-?[0-9]+$'


#doppelte Ausfuehrungsgeschwindigkeit
if [[ $dspeed == "1" ]]; then
	if [ -e ramdisk/5sec ]; then
		sleep 5 && ./regel.sh >> /var/log/openWB.log 2>&1 &
		rm ramdisk/5sec
	else
		touch ramdisk/5sec
	fi
fi

#logfile aufräumen
if [[ $debug == "1" ]]; then
	echo "$(tail -100 /var/log/openWB.log)" > /var/log/openWB.log
fi
#######################################
# Werte für die Berechnung ermitteln
llalt=$(cat /var/www/html/openWB/ramdisk/llsoll)
#PV Leistung ermitteln
if [[ $pvwattmodul != "none" ]]; then
	pvwatt=$(modules/$pvwattmodul/main.sh)
	if ! [[ $pvwatt =~ $re ]] ; then
		pvwatt="0"
	fi
	if [[ $debug == "1" ]]; then
                date
		echo pvwatt $pvwatt
        fi
else
	pvwatt=0
fi
#Wattbezug	
if [[ $wattbezugmodul != "none" ]]; then
	wattbezug=$(modules/$wattbezugmodul/main.sh)
	if ! [[ $wattbezug =~ $re ]] ; then
	wattbezug="0"
	fi
	#uberschuss zur berechnung
	wattbezugint=$(printf "%.0f\n" $wattbezug)
	uberschuss=$((wattbezugint * -1))
	if [[ $debug == "1" ]]; then
		echo wattbezug $wattbezug
		echo uberschuss $uberschuss
	fi
	evua1=$(cat /var/www/html/openWB/ramdisk/bezuga1)
	evua2=$(cat /var/www/html/openWB/ramdisk/bezuga2)
	evua3=$(cat /var/www/html/openWB/ramdisk/bezuga3)
else
	wattbezug=$pvwatt
	wattbezugint=$(printf "%.0f\n" $wattbezug)
	wattbezugint=$(echo "($wattbezugint+300)" |bc)
	echo "$wattbezugint" > /var/www/html/openWB/ramdisk/wattbezug
	uberschuss=$((wattbezugint * -1))
	
fi
#Ladeleistung ermitteln
if [[ $ladeleistungmodul != "none" ]]; then
	timeout 10 modules/$ladeleistungmodul/main.sh
	lla1=$(cat /var/www/html/openWB/ramdisk/lla1)
	lla2=$(cat /var/www/html/openWB/ramdisk/lla2)
	lla3=$(cat /var/www/html/openWB/ramdisk/lla3)	
	ladeleistung=$(cat /var/www/html/openWB/ramdisk/llaktuell)
		if ! [[ $lla1 =~ $re ]] ; then
		 lla1="0"
	fi
	if ! [[ $lla2 =~ $re ]] ; then
		 lla2="0"
	fi

	if ! [[ $lla3 =~ $re ]] ; then
		 lla3="0"
	fi
	if ! [[ $ladeleistung =~ $re ]] ; then
		 ladeleistung="0"
	fi

else
	lla1=0
	lla2=0
	lla3=0
	ladeleistung=800
fi
#zweiter ladepunkt
if [[ $lastmanagement == "1" ]]; then
	timeout 10 modules/$ladeleistungs1modul/main.sh
	llalts1=$(cat /var/www/html/openWB/ramdisk/llsolls1)
	ladeleistungs1=$(cat /var/www/html/openWB/ramdisk/llaktuells1)
	llas1=$(cat /var/www/html/openWB/ramdisk/llas11)
	llas2=$(cat /var/www/html/openWB/ramdisk/llas12)
	llas3=$(cat /var/www/html/openWB/ramdisk/llas13)
	if ! [[ $ladeleistungs1 =~ $re ]] ; then
	 ladeleistungs1="0"
	fi
	ladeleistung=$(echo "($ladeleistung+$ladeleistungs1)" |bc)
	echo "$ladeleistung" > /var/www/html/openWB/ramdisk/llkombiniert
else
	echo "$ladeleistung" > /var/www/html/openWB/ramdisk/llkombiniert
fi
#dritter ladepunkt
if [[ $lastmanagements2 == "1" ]]; then
	timeout 10 modules/$ladeleistungs2modul/main.sh
	llalts2=$(cat /var/www/html/openWB/ramdisk/llsolls2)
	ladeleistungs2=$(cat /var/www/html/openWB/ramdisk/llaktuells2)
	llas21=$(cat /var/www/html/openWB/ramdisk/llas21)
	llas22=$(cat /var/www/html/openWB/ramdisk/llas22)
	llas23=$(cat /var/www/html/openWB/ramdisk/llas23)
	if ! [[ $ladeleistungs2 =~ $re ]] ; then
	 ladeleistungs2="0"
	fi
	ladeleistung=$(echo "($ladeleistung+$ladeleistungs2)" |bc)
	echo "$ladeleistung" > /var/www/html/openWB/ramdisk/llkombiniert
else
	echo "$ladeleistung" > /var/www/html/openWB/ramdisk/llkombiniert
fi
	if [[ $debug == "1" ]]; then
                echo ladeleistung "$ladeleistung" llalt "$llalt" nachtladen "$nachtladen" minimalA "$minimalstromstaerke" maximalA "$maximalstromstaerke"
		echo lla1 "$lla1" llas1 "$llas1" llas21 "$llas21" mindestuberschuss "$mindestuberschuss" abschaltuberschuss "$abschaltuberschuss"
		echo lla2 "$lla2" llas2 "$llas2" llas22 "$llas22" sofortll "$sofortll"
		echo lla3 "$lla3" llas3 "$llas3" llas23 "$llas23"
		echo evua 1,2,3 "$evua1" "$evua2" "$evua3"
        fi


#Soc ermitteln
if [[ $socmodul != "none" ]]; then
	soc=$(timeout 10 modules/$socmodul/main.sh)
	if ! [[ $soc =~ $re ]] ; then
	 soc="0"
	fi
	if [[ $debug == "1" ]]; then
                echo soc $soc
        fi
else
	soc=0
fi
#Uhrzeit
	date=$(date)
	H=$(date +%H)

#########################################
#Regelautomatiken

########################
# Sofort Laden
if grep -q 0 "/var/www/html/openWB/ramdisk/lademodus"; then
	#mit einem Ladepunkt
	if [[ $lastmanagement == "0" ]]; then
		if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
			runs/$minimalstromstaerke.sh
			if [[ $debug == "1" ]]; then
		               	echo starte sofort Ladeleistung von $minimalstromstaerke aus
        		fi
			exit 0
		fi
		if grep -q 1 "/var/www/html/openWB/ramdisk/ladestatus"; then
			if (( $evua1 < $lastmaxap1 )) && (( $evua2 < $lastmaxap2 )) &&  (( $evua3 < $lastmaxap3 )); then
				if (( $ladeleistung < 500 )); then
					if (( $llalt > $minimalstromstaerke )); then
	                                	llneu=$((llalt - 1 ))
	                                	runs/"$llneu"m.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung reudziert auf $llneu bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
	                                	exit 0
					fi
					if (( $llalt == $minimalstromstaerke )); then
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
						exit 0
					fi
					if (( $llalt < $minimalstromstaerke )); then
						llneu=$((llalt + 1 ))
						runs/"$llneu"m.sh
						if [[ $debug == "1" ]]; then
	       	             				echo "Sofort ladung erhöht auf $llneu bei minimal A $minimalstromstaerke Ladeleistung zu gering"
	     					fi
						exit 0
					fi
				else
					if (( $llalt == $sofortll )); then
						if [[ $debug == "1" ]]; then
	       	        	     			echo "Sofort ladung erreicht bei $sofortll A"
	     					fi
						exit 0
					fi
					if (( $llalt > $maximalstromstaerke )); then
						llneu=$((llalt - 1 ))
						runs/"$llneu"m.sh
						if [[ $debug == "1" ]]; then
	       		             			echo "Sofort ladung auf $llneu reduziert, über eingestellter max A $maximalstromstaerke"
	     					fi
						exit 0
					fi
					if (( $llalt < $sofortll)); then
						evudiff1=$((lastmaxap1 - $evua1 ))
						evudiff2=$((lastmaxap2 - $evua2 ))
						evudiff3=$((lastmaxap3 - $evua3 ))
						evudiffmax=($evudiff1 $evudiff2 $evudiff3)
						maxdiff=0
						for v in "${evudiffmax[@]}"; do
							if (( $v > $maxdiff )); then maxdiff=$v; fi;
						done
						llneu=$((llalt + maxdiff))
						if (( $llneu > $sofortll )); then
							llneu=$sofortll
						fi
						runs/"$llneu"m.sh
		                		if [[ $debug == "1" ]]; then
	       	             				echo "Sofort ladung um $maxdiff A Differenz auf $llneu A erhoeht, kleiner als sofortll $sofortll"
	     					fi
						exit 0
					fi
					if (( $llalt > $sofortll)); then
						llneu=$sofortll
						runs/"$llneu"m.sh
			                	if [[ $debug == "1" ]]; then
	       		             			echo "Sofort ladung von $llalt A llalt auf $llneu A reduziert, größer als sofortll $sofortll"
	     					fi
						exit 0
					fi
				fi
			else
				evudiff1=$((evua1 - $lastmaxap1 ))
				evudiff2=$((evua2 - $lastmaxap2 ))
				evudiff3=$((evua3 - $lastmaxap3 ))
				evudiffmax=($evudiff1 $evudiff2 $evudiff3)
				maxdiff=0
				for v in "${evudiffmax[@]}"; do
					if (( $v > $maxdiff )); then maxdiff=$v; fi;
				done
				maxdiff=$((maxdiff + 1 ))
				llneu=$((llalt - maxdiff))
				if (( $llneu < $minimalstromstaerke )); then
					llneu=$minimalstromstaerke
					if [[ $debug == "1" ]]; then
						echo Differenz groesser als minimalstromstaerke, setze auf minimal A $minimalstromstaerke
					fi
				fi
				runs/"$llneu"m.sh
	        	        if [[ $debug == "1" ]]; then
       	        	     		echo "Sofort ladung um $maxdiff auf $llneu reduziert"
     				fi
				exit 0
			fi
		fi		
	else
		if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
			llneu=$minimalstromstaerke
			runs/$minimalstromstaerke.sh
			if [[ $debug == "1" ]]; then
		               	echo starte sofort Ladeleistung mit mehreren Ladepunkten von $minimalstromstaerke aus
        		fi
			exit 0
		fi
		if grep -q 1 "/var/www/html/openWB/ramdisk/ladestatus"; then
			if (( $evua1 < $lastmaxap1 )) && (( $evua2 < $lastmaxap2 )) &&  (( $evua3 < $lastmaxap3 )); then
				evudiff1=$((lastmaxap1 - $evua1 ))
				evudiff2=$((lastmaxap2 - $evua2 ))
				evudiff3=$((lastmaxap3 - $evua3 ))
				evudiffmax=($evudiff1 $evudiff2 $evudiff3)
				maxdiff=0
				for v in "${evudiffmax[@]}"; do
					if (( $v > $maxdiff )); then maxdiff=$v; fi;
				done
				maxdiff=$((maxdiff - 1 ))
				#Ladepunkt 1
				if (( $ladeleistung < 500 )); then
					if (( $llalt > $minimalstromstaerke )); then
	                                	llneu=$((llalt - 1 ))
	                                	runs/"$llneu"m.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 1 reudziert auf $llneu bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
	                                fi
					if (( $llalt == $minimalstromstaerke )); then
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 1 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
					fi
					if (( $llalt < $minimalstromstaerke )); then
						llneu=$((llalt + 1 ))
						runs/"$llneu"m.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 1 erhöht auf $llneu bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
					fi
				else
					if (( $llalt == $sofortll )); then
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 1 erreicht bei $sofortll A"
		     				fi
					fi
					if (( $llalt > $maximalstromstaerke )); then
						llneu=$((llalt - 1 ))
						runs/"$llneu"m.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 1 auf $llneu reduziert, über eingestellter max A $maximalstromstaerke"
		     				fi
					else
						if (( $llalt < $sofortll)); then
	
							llneu=$((llalt + maxdiff))
							if (( $llneu > $sofortll )); then
								llneu=$sofortll
							fi
							runs/"$llneu"m.sh
			                		if [[ $debug == "1" ]]; then
		       	             				echo "Sofort ladung Ladepunkt 1 um $maxdiff A Differenz auf $llneu A erhoeht, war kleiner als sofortll $sofortll"
		     					fi
						fi
						if (( $llalt > $sofortll)); then
							llneu=$sofortll
							runs/"$llneu"m.sh
			                		if [[ $debug == "1" ]]; then
		       	             				echo "Sofort ladung Ladepunkt 1 von $llalt A llalt auf $llneu A reduziert, war größer als sofortll $sofortll"
		     					fi
						fi
					fi
				fi
				#Ladepunkt 2
				if (( $ladeleistungs1 < 500 )); then
					if (( $llalts1 > $minimalstromstaerke )); then
        	                        	llneus1=$((llalts1 - 1 ))
        	                        	runs/"$llneus1"s1.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 2 reudziert auf $llneus1 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
        	                        fi
					if (( $llalts1 == $minimalstromstaerke )); then
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 2 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
					fi
					if (( $llalts1 < $minimalstromstaerke )); then
						llneus1=$((llalts1 + 1 ))
						runs/"$llneus1"s1.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 2 erhöht auf $llneus1 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
		     				fi
					fi
				else
					if (( $llalts1 == $sofortlls1 )); then
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 2 erreicht bei $sofortlls1 A"
		     				fi
					fi
					if (( $llalts1 > $maximalstromstaerke )); then
						llneus1=$((llalts1 - 1 ))
						runs/"$llneus1"s1.sh
						if [[ $debug == "1" ]]; then
		       	             			echo "Sofort ladung Ladepunkt 2 auf $llneus1 reduziert, über eingestellter max A $maximalstromstaerke"
		     				fi
					else
						if (( $llalts1 < $sofortlls1)); then
							llneus1=$((llalts1 + maxdiff))
							if (( $llneus1 > $sofortlls1 )); then
								llneus1=$sofortlls1
							fi
							runs/"$llneus1"s1.sh
			                		if [[ $debug == "1" ]]; then
		       	             				echo "Sofort ladung Ladepunkt 2 um $maxdiff A Differenz auf $llneus1 A erhoeht, war kleiner als sofortll $sofortlls1"
		     					fi
						fi
						if (( $llalts1 > $sofortlls1)); then
							llneus1=$sofortlls1
							runs/"$llneus1"s1.sh
			                		if [[ $debug == "1" ]]; then
	       		             				echo "Sofort ladung Ladepunkt 2 von $llalts1 A llalt auf $llneus1 A reduziert, war größer als sofortll $sofortlls1"
	     						fi
						fi
					fi
				fi
				#Ladepunkt 3
				if [[ $lastmanagements2 == "1" ]]; then 
					if (( ladeleistungs2 < 500 )); then
						if (( llalts2 > minimalstromstaerke )); then
			                                	llneus2=$((llalts2 - 1 ))
	                                	runs/"$llneus2"s2.sh
							if [[ $debug == "1" ]]; then
			       	             			echo "Sofort ladung Ladepunkt 3 reudziert auf $llneus2 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
			     				fi
		                                fi
						if (( llalts2 == minimalstromstaerke )); then
							if [[ $debug == "1" ]]; then
			       	             			echo "Sofort ladung Ladepunkt 3 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
			     				fi
						fi
						if (( llalts2 < minimalstromstaerke )); then
							llneus2=$((llalts2 + 1 ))
							runs/"$llneus2"s2.sh
							if [[ $debug == "1" ]]; then
			       	             			echo "Sofort ladung Ladepunkt 3 erhöht auf $llneus2 bei minimal A $minimalstromstaerke Ladeleistung zu gering"
			     				fi
						fi
					else
						if (( llalts2 == sofortlls2 )); then
							if [[ $debug == "1" ]]; then
			       	             			echo "Sofort ladung Ladepunkt 3 erreicht bei $sofortlls2 A"
			     				fi
						fi
						if (( llalts2 > maximalstromstaerke )); then
							llneus2=$((llalts2 - 1 ))
							runs/"$llneus2"s2.sh
							if [[ $debug == "1" ]]; then
			       	             			echo "Sofort ladung Ladepunkt 3 auf $llneus2 reduziert, über eingestellter max A $maximalstromstaerke"
			     				fi
						else
							if (( llalts2 < sofortlls2)); then
								llneus2=$((llalts2 + maxdiff))
								if (( llneus2 > sofortlls2 )); then
									llneus2=$sofortlls2
								fi
								runs/"$llneus2"s2.sh
				                		if [[ $debug == "1" ]]; then
		       		             				echo "Sofort ladung Ladepunkt 3 um $maxdiff A Differenz auf $llneus2 A erhoeht, war kleiner als sofortll $sofortlls2"
		     						fi
							fi
							if (( llalts2 > sofortlls2)); then
								llneus2=$sofortlls2
								runs/"$llneus2"s2.sh
		        	        			if [[ $debug == "1" ]]; then
	       	        	     					echo "Sofort ladung Ladepunkt 3 von $llalts2 A llalt auf $llneus2 A reduziert, war größer als sofortll $sofortlls2"
	     							fi
							fi
						fi
					fi
				fi
				exit 0
			else
				evudiff1=$((evua1 - lastmaxap1 ))
				evudiff2=$((evua2 - lastmaxap2 ))
				evudiff3=$((evua3 - lastmaxap3 ))
				evudiffmax=($evudiff1 $evudiff2 $evudiff3)
				maxdiff=0
				for v in "${evudiffmax[@]}"; do
					if (( $v > $maxdiff )); then maxdiff=$v; fi;
				done
				maxdiff=$((maxdiff + 1 ))
				llneu=$((llalt - maxdiff))
				llneus1=$((llalts1 - maxdiff))
				if [[ $lastmanagements2 == "1" ]]; then 
					llneus2=$((llalts2 - maxdiff))
				fi
				if (( llneu < minimalstromstaerke )); then
					llneu=$minimalstromstaerke
					if [[ $debug == "1" ]]; then
						echo Ladepunkt 1 Differenz groesser als minimalstromstaerke, setze auf minimal A $minimalstromstaerke
					fi
				fi
				if (( llneus1 < minimalstromstaerke )); then
					llneus1=$minimalstromstaerke
					if [[ $debug == "1" ]]; then
						echo Ladepunkt 2 Differenz groesser als minimalstromstaerke, setze auf minimal A $minimalstromstaerke
					fi
				fi
				if [[ $lastmanagements2 == "1" ]]; then 
					if (( $llneus2 < $minimalstromstaerke )); then
						llneus2=$minimalstromstaerke
						if [[ $debug == "1" ]]; then
						echo Ladepunkt 3 Differenz groesser als minimalstromstaerke, setze auf minimal A $minimalstromstaerke
						fi
					fi
				fi	
				runs/"$llneu"m.sh
				runs/"$llneus1"s1.sh
				if [[ $lastmanagements2 == "1" ]]; then
				       runs/"$llneus2"s2.sh
				fi	       
		                if [[ $debug == "1" ]]; then
       		             		echo "Sofort ladung um $maxdiff auf $llneu reduziert"
     				fi
				exit 0		
			fi
		fi
	fi
fi
####################
# Nachtladung bzw. Ladung bis SOC x% nachts von x bis x Uhr
if [[ $nachtladen == "1" ]]; then
	if (( $nachtladenabuhr <= 10#$H && 10#$H <= 24 )) || (( 0 <= 10#$H && 10#$H <= $nachtladenbisuhr )); then
		dayoftheweek=$(date +%w)
		if [ "$dayoftheweek" -ge 0 ] && [ "$dayoftheweek" -le 4 ]; then
		
			diesersoc=$nachtsoc
		else
			diesersoc=$nachtsoc1
		fi


		if [[ $socmodul != "none" ]]; then
			if [[ $debug == "1" ]]; then
                		echo nachtladen mit socmodul $socmodul
        		fi

			if (( $soc <= $diesersoc )); then
				if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
					runs/$nachtll.sh
					if [[ $debug == "1" ]]; then
		                		echo "soc $soc"
		        			echo "ladeleistung nachtladen bei $nachtll"
					fi
					exit 0
				fi
				if grep -q $nachtll "/var/www/html/openWB/ramdisk/llsoll"; then
					exit 0
				else
					runs/$nachtll.sh
					if [[ $debug == "1" ]]; then
	                		echo aendere nacht Ladeleistung auf $nachtll
	        			fi
				exit 0
				fi

				exit 0
			else
				if grep -q 1 "/var/www/html/openWB/ramdisk/ladestatus"; then
					runs/0.sh
					exit 0
				fi
				exit 0
			fi
		fi
		if [[ $socmodul == "none" ]]; then
			if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
			#	runs/ladungan.sh
                                runs/$nachtll.sh
                                if [[ $debug == "1" ]]; then
                                	echo "soc $soc"
                                        echo "ladeleistung nachtladen $nachtll A"
                                fi
                                echo "start Nachtladung mit $nachtll um $date" >> web/lade.log
                                exit 0
			fi
		exit 0
		fi	
	fi
fi
#######################
#Ladestromstarke berechnen
llphasentest=$((llalt - 3))

#Anzahl genutzter Phasen ermitteln, wenn ladestrom kleiner 3 (nicht vorhanden) nutze den letzten bekannten wert
if (( $llalt > 3 )); then
	anzahlphasen=0
	if [ $lla1 -ge $llphasentest ]; then
		anzahlphasen=$((anzahlphasen + 1 ))
	fi
	if [ $lla2 -ge $llphasentest ]; then
	        anzahlphasen=$((anzahlphasen + 1 ))
	fi
	if [ $lla3 -ge $llphasentest ]; then
	        anzahlphasen=$((anzahlphasen + 1 ))
	fi
	if [ $anzahlphasen -eq 0 ]; then
		anzahlphasen=1
	fi
	echo $anzahlphasen > /var/www/html/openWB/ramdisk/anzahlphasen
	else
	if [ ! -f /var/www/html/openWB/ramdisk/anzahlphasen ]; then
    		echo 1 > /var/www/html/openWB/ramdisk/anzahlphasen
	fi
	anzahlphasen=$(cat /var/www/html/openWB/ramdisk/anzahlphasen)
fi

########################
# Berechnung für PV Regelung
mindestuberschussphasen=$(echo "($mindestuberschuss*$anzahlphasen)" | bc)
wattkombiniert=$(echo "($ladeleistung+$uberschuss)" | bc)
abschaltungw=$(echo "(($abschaltuberschuss-1320)*-1*$anzahlphasen)" | bc)
schaltschwelle=$(echo "(230*$anzahlphasen)" | bc)

	if [[ $debug == "2" ]]; then
		echo "$date"
		echo uberschuss "$uberschuss"
		echo wattbezug "$wattbezug"
		echo "$(cat ramdisk/ladestatus)"
		echo llsoll "$llalt"
		echo pvwatt "$pvwatt"
    		echo mindestuberschussphasen "$mindestuberschussphasen"
		echo wattkombiniert "$wattkombiniert"
		echo abschaltungw "$abschaltungw"
		echo schaltschwelle "$schaltschwelle"
        fi
#PV Regelmodus
if [[ $pvbezugeinspeisung == "0" ]]; then
	pvregelungm="0"
fi


if [[ $pvbezugeinspeisung == "1" ]]; then
	pvregelungm=$(echo "(230*$anzahlphasen*-1)" | bc)
	schaltschwelle="0"
fi
########################
#Min Ladung + PV Uberschussregelung lademodus 1
if grep -q 1 "/var/www/html/openWB/ramdisk/lademodus"; then
	if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
		runs/$minimalampv.sh
		exit 0
                if [[ $debug == "1" ]]; then
                     	echo "starte min + pv ladung mit $minimalampv"
                fi
	fi
	if grep -q 1 "/var/www/html/openWB/ramdisk/ladestatus"; then
		if (( $ladeleistung < 500 )); then
			if (( $llalt > $minimalampv )); then
                                llneu=$((llalt - 1 ))
                                runs/$llneu.sh
		                if [[ $debug == "1" ]]; then
        	             		echo "min + pv ladung auf $llneu reduziert, llalt groesser als minimalampv"
               			fi
                                exit 0
			fi
			if (( $llalt = $minimalampv )); then
                                exit 0
			fi
			if (( $llalt < $minimalampv )); then
                                llneu=$((llalt + 1 ))
                                runs/$llneu.sh
                                exit 0
			fi
		fi	
		if (( $uberschuss < $pvregelungm )); then
                	if (( $llalt > $minimalampv )); then
                                llneu=$((llalt - 1 ))
                                runs/$llneu.sh
		                if [[ $debug == "1" ]]; then
        	             		echo "min + pv ladung auf $llneu reduziert"
               			fi
                                exit 0
                        else
				if (( $llalt < $minimalampv )); then
					llneu=$((llalt + 1 ))
					runs/$llneu.sh
				fi	
				exit 0
                        fi
                fi
		if (( $uberschuss > $schaltschwelle )); then
                        if (( $llalt == $maximalstromstaerke )); then
                                exit 0
                        fi
                        llneu=$((llalt + 1 ))
                        runs/$llneu.sh
	                if [[ $debug == "1" ]]; then
       	             		echo "min + pv ladung auf $llneu erhoeht"
     			fi
                	exit 0
		fi
	fi
fi
########################
#NUR PV Uberschussregelung lademodus 2
# wenn evse aus und $mindestuberschuss vorhanden, starte evse mit 6A Ladestromstaerke (1320 - 3960 Watt je nach Anzahl Phasen)
if grep -q 2 "/var/www/html/openWB/ramdisk/lademodus"; then
	if grep -q 0 "/var/www/html/openWB/ramdisk/ladestatus"; then
			if (( $mindestuberschussphasen <= $uberschuss )); then
		                if [[ $debug == "1" ]]; then
        	             		echo "nur  pv ladung auf $minimalapv starten"
               			fi
				runs/$minimalapv.sh
				echo 0 > /var/www/html/openWB/ramdisk/pvcounter 
				exit 0
			else
				exit 0
			fi	
	fi
	if (( $ladeleistung < 500 )); then
		if (( $llalt > $minimalapv )); then
                        llneu=$((llalt - 1 ))
                        runs/$llneu.sh
			echo 0 > /var/www/html/openWB/ramdisk/pvcounter 
                        exit 0
		fi
		if (( $llalt < $minimalapv )); then
                        llneu=$((llalt + 1 ))
                        runs/$llneu.sh
			echo 0 > /var/www/html/openWB/ramdisk/pvcounter 
                        exit 0
		fi
		if (( $llalt == $minimalapv )); then
                        if (( $wattbezugint > $abschaltuberschuss )); then 
				pvcounter=$(cat /var/www/html/openWB/ramdisk/pvcounter)
				if (( $pvcounter < $abschaltverzoegerung )); then
					pvcounter=$((pvcounter + 10))
					echo $pvcounter > /var/www/html/openWB/ramdisk/pvcounter
					if [[ $debug == "1" ]]; then
        	             			echo "Nur PV auf Minimalstromstaerke, PV Counter auf $pvcounter erhöht"
               				fi
				else
					runs/0.sh
					if [[ $debug == "1" ]]; then
						echo "pv ladung beendet"
					fi
				fi
			fi
		fi
	else
		if (( $uberschuss > $schaltschwelle )); then
			if (( $llalt == $maximalstromstaerke )); then
				exit 0
			fi
			if (( $uberschuss > 1000 )); then
				llneu=$((llalt + 3 ))
				if (( $llneu > $maximalstromstaerke )); then
					llneu=$maximalstromstaerke
				fi
			else
				llneu=$((llalt + 1 ))
			fi
			if (( $llalt < $minimalapv )); then
				llneu=$minimalapv
			fi
			runs/$llneu.sh
		        if [[ $debug == "1" ]]; then
       		      		echo "pv ladung auf $llneu erhoeht"
     			fi
			echo 0 > /var/www/html/openWB/ramdisk/pvcounter 
			exit 0
		fi	
		if (( $uberschuss < $pvregelungm )); then
			if (( $llalt > $minimalapv )); then
				if (( $uberschuss < -1000 )); then
					llneu=$((llalt - 3 ))
					if (( $llneu < $minimalapv )); then
						llneu=$minimalapv
					fi
				else
					llneu=$((llalt - 1 ))
				fi
				runs/$llneu.sh
				echo 0 > /var/www/html/openWB/ramdisk/pvcounter 
	        	        if [[ $debug == "1" ]]; then
					echo "pv ladung auf $llneu reduziert"
				fi
	        	        exit 0
	        	else
				if (( wattbezugint > abschaltuberschuss )); then 
					pvcounter=$(cat /var/www/html/openWB/ramdisk/pvcounter)
					if (( pvcounter < abschaltverzoegerung )); then
						pvcounter=$((pvcounter + 10))
						echo $pvcounter > /var/www/html/openWB/ramdisk/pvcounter
						if [[ $debug == "1" ]]; then
                	     				echo "Nur PV auf Minimalstromstaerke, PV Counter auf $pvcounter erhöht"
        					fi
					else
						runs/0.sh
						if [[ $debug == "1" ]]; then
							echo "pv ladung beendet"
						fi
						echo 0 > /var/www/html/openWB/ramdisk/pvcounter 
					fi
					exit 0
				fi
	        	fi
		fi
	fi
fi
	
	


#Lademodus 3 == Aus

if grep -q 3 "/var/www/html/openWB/ramdisk/lademodus"; then
	if grep -q 1 "/var/www/html/openWB/ramdisk/ladestatus"; then
		runs/0.sh
		exit 0
	else
		exit 0
	fi
fi








