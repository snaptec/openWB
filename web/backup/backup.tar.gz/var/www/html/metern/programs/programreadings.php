<?php
define('checkaccess', TRUE);
include('../config/config_main.php');
date_default_timezone_set('UTC');

if (isset($_COOKIE['user_lang'])) {
    $user_lang = $_COOKIE['user_lang'];
} else {
    $user_lang = 'English';
}
include('../languages/' . $user_lang . '.php');

if (!empty($_GET['meter']) && is_numeric($_GET['meter'])) {
    $meter = (int) $_GET['meter'];
} else {
$meter =1;
//    die();
}
if (file_exists("../config/config_met$meter.php")) {
    include("../config/config_met$meter.php");
} else {
    die();
}

$meteryearlist = array();
$meteryearlist = glob('../data/meters/' . $meter . ${'METNAME' . $meter} . '*.csv'); // 1Elect*
if (is_array($meteryearlist)) {
    sort($meteryearlist);
}
$yearscnt = count($meteryearlist);

$topseries[0] = array(
    'name' => "${'METNAME'.$meter}",
    'title' => "${'METNAME'.$meter}",
    'keys' => array(
        'x',
        'y',
        'drilldown',
        'title'
    )
);

$ncnt = 0;
for ($i = 0; $i < $yearscnt; $i++) {
    $year = substr($meteryearlist[$i], -8, 4);
    
    $thefile    = file('../data/meters/' . $meter . ${'METNAME' . $meter} . $year . '.csv');
    $contalines = count($thefile);
    $year       = (int) $year;
    
    for ($line_num = 0; $line_num < $contalines; $line_num++) {
        $array                          = preg_split("/,/", $thefile[$line_num]);
        $month                          = substr($array[0], 4, 2);
        $day                            = substr($array[0], 6, 2);
        $month                          = (int) ($month);
        $day                            = (int) ($day);
        $conso_day[$year][$month][$day] = (float) ($array[1]);
        if (${'TYPE' . $meter} == 'Elect') {
            $conso_day[$year][$month][$day] /= 1000;
        }
    } // end of looping through the file

        if ($year == date('Y')) { // Add today
            $output = glob('../data/csv/*.csv');
            rsort($output);
            if (isset($output[0])) {
                $file       = file($output[0]);
                $month      = (int) substr($output[0], -8, 2);
                $day        = (int) substr($output[0], -6, 2);
                $contalines = count($file);
                $prevarray  = preg_split('/,/', $file[1]);
                $linearray  = preg_split('/,/', $file[$contalines - 1]);
                $val_first  = (float) $prevarray[$meter];
                $conso_day[$year][$month][$day]   = (float)$linearray[$meter];
                if (!empty($val_first) && !empty($conso_day[$year][$month][$day])) {
                    if ($val_first <= $conso_day[$year][$month][$day]) {
                        $conso_day[$year][$month][$day] -= $val_first;
                    } else { // counter pass over
                        $conso_day[$year][$month][$day] += ${'PASSO' . $meter} - $val_first;
                    }
                } else {
                    $conso_day[$year][$month][$day] = 0;
                }
		   if (${'TYPE' . $meter} == 'Elect') {
		        $conso_day[$year][$month][$day] /= 1000;
		    } else {
		$conso_day[$year][$month][$day] = round($conso_day[$year][$month][$day], ${'PRECI' . $meter});
		    }
            }
        } // end of today
    
    $conso_y = 0;
    for ($h = 1; $h <= 12; $h++) { // Fill blanks dates and drilldowndays
        $daythatm = cal_days_in_month(CAL_GREGORIAN, $h, $year);
        $day      = 0;
        for ($j = 1; $j <= $daythatm; $j++) {
            $epochdate = strtotime($h . '/' . $j . '/' . $year) * 1000;
            if (!isset($conso_day[$year][$h][$j])) {
                $conso_day[$year][$h][$j]       = 0;
                $drilldowndays[$year][$h][$day] = array(
                    $epochdate,
                    0
                );
            } else {
                $drilldowndays[$year][$h][$day] = array(
                    $epochdate,
                    $conso_day[$year][$h][$j]
                );
            }
            $day++;
        }
        $conso_y += array_sum($conso_day[$year][$h]);
    }
    
    $title = "${'METNAME'.$meter} $year: ";
    if (${'TYPE' . $meter} == 'Elect') {
        $title .= number_format($conso_y, 1, $DPOINT, $THSEP);
        $title .= " kWh";
    } else {
        $title .= number_format($conso_y, ${'PRECI' . $meter}, $DPOINT, $THSEP);
        $title .= " ${'UNIT'.$meter}";
    }
    if (${'PRICE' . $meter} > 0) {
        $money = number_format(($conso_y * ${'PRICE' . $meter}), 1, $DPOINT, $THSEP);
        $title .= "/$money $CURS";
    }
    
    $epochdate                = strtotime('1/1/' . $year) * 1000;
    $topseries[0]['data'][$i] = array(
        $epochdate,
        $conso_y,
        "y$year",
        $title
    );
    
    $month = 0;
    for ($h = 1; $h <= 12; $h++) { // drilldownmonths
        if ($h == 1) {
            $return['series'][$ncnt]['id']   = 'y' . $year; //y2015
            $return['series'][$ncnt]['name'] = "${'METNAME'.$meter} $year";
            $thisy                           = $ncnt;
            $ncnt++;
        }
        
        $conso_m = array_sum($conso_day[$year][$h]);
        $title   = "${'METNAME'.$meter} $lgMONTH[$h] $year: ";
        if (${'TYPE' . $meter} == 'Elect') {
            $title .= number_format($conso_m, 1, $DPOINT, $THSEP);
            $title .= ' kWh';
        } else {
            $title .= number_format($conso_m, ${'PRECI' . $meter}, $DPOINT, $THSEP);
            $title .= " ${'UNIT'.$meter}";
        }
        if (${'PRICE' . $meter} > 0) {
            $money = number_format(($conso_m * ${'PRICE' . $meter}), 1, $DPOINT, $THSEP);
            $title .= "/$money $CURS";
        }
        $epochdate                      = strtotime($h . '/1/' . $year) * 1000;
        $drilldownmonths[$year][$month] = array(
            $epochdate,
            $conso_m,
            "m$year$h",
            $title
        );
        
        $return['series'][$ncnt]['id']   = 'm' . $year . $h; //m201508
        $return['series'][$ncnt]['name'] = "$lgSMONTH[$h] $year";
        $return['series'][$ncnt]['data'] = $drilldowndays[$year][$h];
        $return['series'][$ncnt]['keys'] = array(
            'x',
            'y',
            'drilldown'
        );
        $ncnt++;
        $month++;
    } // each month
    
    $return['series'][$thisy]['data'] = $drilldownmonths[$year];
    $return['series'][$thisy]['keys'] = array(
        'x',
        'y',
        'drilldown',
        'title'
    );
} // each year file

$jsonreturn = array(
    'series' => $topseries,
    'drilldown' => $return
);

header("Content-type: text/json");
echo json_encode($jsonreturn);
?>
