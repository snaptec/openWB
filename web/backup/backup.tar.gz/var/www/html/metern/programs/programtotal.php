<?php
define('checkaccess', TRUE);
include('../config/config_main.php');

$dir    = '../data/csv/';
$output = glob($dir . '/*.csv');
rsort($output);
if (isset($output[0])) {
    for ($i = 1; $i <= $NUMMETER; $i++) {
        include("../config/config_met$i.php");
        
        if (${'TYPE' . $i} != 'Sensor') {
            $lines      = file($output[0]);
            $month      = substr($output[0], -8, 2);
            $day        = substr($output[0], -6, 2);
            $contalines = count($lines);
            
            $val_last  = null;
            $val_first = null;
            $j         = 0;
            while (!isset($val_first)) {
                $j++;
                $array     = preg_split('/,/', $lines[$j]);
                $val_first = isset($array[$i]) ? trim($array[$i]) : '';
                if ($val_first == '') { // if skipped
                    $val_first = null;
                }
                if ($j == $contalines - 1) {
                    $val_first = 0; // didn't find any prev. first value
                }
            }
            $j = 0;
            while (!isset($val_last)) {
                $j++;
                $array    = preg_split('/,/', $lines[$contalines - $j]);
                $val_last = isset($array[$i]) ? trim($array[$i]) : '';
                $val_last = isset($array[$i]) ? trim($array[$i]) : '';
                if ($val_last == '') {
                    $val_last = null;
                }
                if ($j == $contalines - 1) {
                    $val_last = 0;
                }
            }
            settype($val_last, 'float');
            settype($val_first, 'float');
            
            if (${'TYPE' . $i} == 'Elect') {
                if ($val_last <= 1000) {
                    $prefix  = '';
                    $val_tot = number_format($val_last, 0, $DPOINT, $THSEP);
                } elseif ($val_last > 1000) {
                    $val_tot = $val_last / 1000;
                    $prefix  = 'k';
                    $val_tot = number_format($val_tot, 3, $DPOINT, $THSEP);
                }
            } else {
                settype(${'PRECI' . $i}, 'integer');
                $val_tot = number_format($val_last, ${'PRECI' . $i}, $DPOINT, $THSEP);
                $prefix  = '';
            }
            $data["Totalcounter$i"] = "$val_tot $prefix";
            
            if ($val_first <= $val_last) {
                $val_last -= $val_first;
            } else { // counter pass over
                $val_last += ${'PASSO' . $i} - $val_first;
            }
            
            if (${'TYPE' . $i} == 'Elect') {
                if ($val_last <= 1000) {
                    $prefix   = '';
                    $val_last = number_format($val_last, 0, $DPOINT, $THSEP);
                } elseif ($val_last > 1000) {
                    $val_last /= 1000;
                    $prefix   = 'k';
                    $val_last = number_format($val_last, 3, $DPOINT, $THSEP);
                }
            } else {
                settype(${'PRECI' . $i}, 'integer');
                $val_last = number_format($val_last, ${'PRECI' . $i}, $DPOINT, $THSEP);
                $prefix   = '';
            }
            $data["Dailycounter$i"] = "$val_last $prefix";
            
        } else {
            $data["Totalcounter$i"] = '--';
            $data["Dailycounter$i"] = '--';
        }
    }
} else {
    for ($i = 1; $i <= $NUMMETER; $i++) {
        $data["Totalcounter$i"] = '--';
        $data["Dailycounter$i"] = '--';
    }
}

header("Content-type: text/json");
echo json_encode($data);
?>
