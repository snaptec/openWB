<?php
include('styles/globalheader.php');
include('config/config_main.php');
include('config/config_indicator.php');

if (!empty($_POST['pool']) && is_numeric($_POST['pool'])) {
    $pool = ($_POST['pool']);
} else {
    $pool = 1000;
}

$poollst = array(
    '5000',
    '2000',
    '1000',
    '500',
    '200',
    '100'
);

echo "
<script type='text/javascript'>
$(document).ready(function() 
{
function updateit() {
$.getJSON('programs/programlive.php', function(json){
CTOT=0;
PTOT=0;";

$housecons = false;
$houseprod = false;
$grid      = array();
for ($i = 1; $i <= $NUMMETER; $i++) {
    include("config/config_met$i.php");
    if (!isset($grid[${'PHASE' . $i}]) && ${'TYPE' . $i} == 'Elect' && ${'PROD' . $i} != 0) {
        
        $grid[${'PHASE' . $i}] = ${'PHASE' . $i}; // grid value on ph n
        echo "G${'PHASE'.$i}=0; 
C${'PHASE'.$i}=0;
P${'PHASE'.$i}=0;
";
    }
    
    echo "val$i =json['${'METNAME'.$i}$i'];
";
    if (${'TYPE' . $i} == 'Elect' && ${'LIVEPOOL' . $i} == 1) {
        echo "
if(isNaN(val$i)){ 
val$i = 0;
} else {
val$i = parseFloat(val$i);
}
";
        if (${'PROD' . $i} == 2) {
            $housecons = true;
            echo "CTOT+=val$i;
C${'PHASE'.$i}+=val$i;
";
        } elseif (${'PROD' . $i} == 1) {
            $houseprod = true;
            echo "PTOT+=val$i;
P${'PHASE'.$i}+=val$i; 
"; // production on ph n
        }
    }
}

sort($grid);
$cnt = count($grid);
if ($cnt > 1) {
    for ($i = 0; $i < $cnt; $i++) {
        echo "
if(isNaN(C$grid[$i])){    
document.getElementById('cval$grid[$i]').innerHTML = 0;
} else {
document.getElementById('cval$grid[$i]').innerHTML = C$grid[$i];
}  
if(isNaN(P$grid[$i])){    
document.getElementById('pval$grid[$i]').innerHTML = 0;
} else {
document.getElementById('pval$grid[$i]').innerHTML = P$grid[$i];
}
grid$grid[$i]=P$grid[$i]-C$grid[$i];
document.getElementById('G$grid[$i]').innerHTML = grid$grid[$i];
";
    }
}

for ($i = 1; $i <= $NUMMETER; $i++) {
    echo "  
if (typeof val$i === 'undefined') {      
document.getElementById('rval$i').innerHTML = 'err';
} else {
";
    if (${'LIVEPOOL' . $i} == 1) { // Value mode
        echo "document.getElementById('rval$i').innerHTML = val$i;
}";
    } else if (${'LIVEPOOL' . $i} == 2) { // State mode
        echo "  if (val$i==1) {
  document.getElementById('rval$i').innerHTML = '<font color=#228B22>On</font>';
  } else {
  document.getElementById('rval$i').innerHTML = '<font color=#8B0000>Off</font>';
  }
}";
    } else { // Disable
        echo "document.getElementById('rval$i').innerHTML = '---';
}";
    }
}

if ($houseprod && $housecons) {
    echo "
GR=parseFloat((PTOT/CTOT)*100);
GR=parseInt(GR);
document.getElementById('rGR').innerHTML = GR;
GRIDTOT=parseInt(PTOT-CTOT);

if (GRIDTOT>=0) {
document.getElementById('rGRIDTOT').style.color = '#228B22';
document.getElementById('gridimage').src = 'images/arrow_l.gif';
} else {
document.getElementById('rGRIDTOT').style.color = '#8B0000';
document.getElementById('gridimage').src = 'images/arrow_r.gif';
}

if (typeof GRIDTOT === 'undefined') {
document.getElementById('rGRIDTOT').innerHTML = 'err';
} else {
document.getElementById('rGRIDTOT').innerHTML = GRIDTOT+' W';
}";
}

if ($houseprod) {
    echo "
PTOT=parseInt(PTOT);
document.getElementById('rPTOT').innerHTML = PTOT;";
}

if ($housecons) {
    echo "
CTOT=parseInt(CTOT);
document.getElementById('rCTOT').innerHTML = CTOT;";
}

echo "
document.getElementById('rSTAMP').innerHTML = json['stamp'];
})";

if ($NUMIND > 0) { // indicators
    echo "
$.getJSON('programs/programindicator.php', function(json){
";
    for ($i = 1; $i <= $NUMIND; $i++) {
        echo "
ival$i =json['${'INDNAME'.$i}$i'];
";
        
        echo "  
if (typeof ival$i === 'undefined') {
document.getElementById('rival$i').innerHTML = 'err';
} else {
";
        if (${'INDPOOL' . $i} == 1) { // Value mode
            echo "document.getElementById('rival$i').innerHTML = ival$i;
}";
        } else if (${'INDPOOL' . $i} == 2) { // State mode
            echo "  if (ival$i==1) {
  document.getElementById('rival$i').innerHTML = '<font color=#228B22>On</font>';
  } else {
  document.getElementById('rival$i').innerHTML = '<font color=#8B0000>Off</font>';
  }
}";
        } else { // Disable
            echo "document.getElementById('rival$i').innerHTML = '---';
}";
        }
    }
    echo "})";
} // indicators
echo " 
} // updateit

function updateit60() {
$.getJSON('programs/programtotal.php', function(json){
";
for ($i = 1; $i <= $NUMMETER; $i++) {
    echo "Totalcounter$i =json['Totalcounter$i'];
document.getElementById('rtval$i').innerHTML = Totalcounter$i;
Dailycounter$i =json['Dailycounter$i'];
document.getElementById('dayval$i').innerHTML = Dailycounter$i;
";
}
echo "
})
} // updateit60

updateit();
setInterval(updateit, $pool);

updateit60();
setInterval(updateit60, 60000);
});
</script>  
<br>
<table border=0 cellspacing=0 cellpadding=5 width=400 align='center'>
<tr><td align='right' colspan=3>
<form method=\"POST\" action=\"$currentFile\">
<select name='pool' onchange='this.form.submit()'>
";
$cnt = count($poollst);
for ($i = 0; $i < $cnt; $i++) {
    if ($pool == $poollst[$i]) {
        echo "<option SELECTED value='$poollst[$i]'>$poollst[$i]</option>";
    } else {
        echo "<option value='$poollst[$i]'>$poollst[$i]</option>";
    }
}
?>
</select> ms
</form>
</td>
</tr>
<tr valign='bottom'>
<td width=100>
<div align='center'><img src="images/powerlines.png" width=54 height=80></div>
</td>
<td width=200>
<div align='center'><font size="-1"><span id='rSTAMP'>--</span></font><br>
<img src="images/house96.png" width="96" height="96">
</div>
</td>
<td width=100>
<div align='center'><img src="images/solarcell.png" width=110 height=59></div>
</td>
</tr>
<tr>
<td align='center'>
<?php
if ($houseprod && $housecons) {
    echo "<span id='rGRIDTOT'>--</span>&nbsp;<img id='gridimage' width=6 height=8>";
}
echo "
</td>
<td><div align='center'>";
if ($housecons) {
    echo "<b><font size='+1'><span id='rCTOT'>--</span> W</b></font>";
}
if ($houseprod && $housecons) {
    echo "<br><font size='-1'>(<span id='rGR'>-</span>% $lgAUTONOM)</font>";
}
echo "
</div>
</td>
<td align='center'>";
if ($houseprod) {
    echo "<span id='rPTOT'>--</span> W</td>";
}
echo "
</tr>
</table>
<br>";

$cnt = count($grid);
if (($houseprod || $housecons) && $cnt > 1) {
    echo "
<table border='1' cellspacing='0' cellpadding='5' width='500' align='center'>
<tr>
<td align='left' colspan=2><font size='-1'>$lgPHASE</td><td align='center'><font size='-1'>$lgCONSUMP</font></td><td align='right'><font size='-1'>$lgPRODUC</font></td>
</tr>
";
    for ($i = 0; $i < $cnt; $i++) {
        echo "<tr>
<td align='left'><font size='-1'>$grid[$i]</font></td>	
<td align='left'><font size='-1'><span id='G$grid[$i]'></span> W</font></td>
<td align='center'><font size='-1'><span id='cval$grid[$i]'></span> W</font></td>
<td align='right'><font size='-1'><span id='pval$grid[$i]'></span> W</font></td></tr>
	";
    }
    echo "
</table>
<br>&nbsp;";
}
echo "
<table border=0 cellspacing=0 cellpadding=5 width=700 align='center'>
<tr align='center'><td width='25%'></td><td width='25%'></td><td width='25%'><b>$lgDAYMETER</b></td><td width='25%'><b>$lgTOTMETER</b></td></tr>
</table>
<table border=1 cellspacing=0 cellpadding=5 width=700 align='center'>
<tbody>
";
for ($i = 1; $i <= $NUMMETER; $i++) {
    echo "<tr align='center'>
<th width='25%'>";
    if (${'LIVEPOOL' . $i} == 1) {
        echo "<b>${'METNAME'.$i}</b></th><th width='25%'><b><span id='rval$i'>--</span> ${'LIVEUNIT'.$i}</b></th><th width='25%'><span id='dayval$i'>--</span>";
        if (${'TYPE' . $i} != 'Sensor') {
            echo "${'UNIT'.$i}";
        }
        echo "</th><th width='25%'><span id='rtval$i'>--</span>";
        if (${'TYPE' . $i} != 'Sensor') {
            echo "${'UNIT'.$i}";
        }
        echo "</th></tr>";
    } else if (${'LIVEPOOL' . $i} == 2) {
        echo "<b>${'METNAME'.$i}</b></th><th width='25%'><b><span id='rval$i'>--</span></b></th><th width='25%'><span id='dayval$i'>--</span>";
        if (${'TYPE' . $i} != 'Sensor') {
            echo "${'UNIT'.$i}";
        }
        echo "</th><th width='25%'><span id='rtval$i'>--</span>";
        if (${'TYPE' . $i} != 'Sensor') {
            echo "${'UNIT'.$i}";
        }
        echo "</th></tr>";
    } else {
        echo "<b>${'METNAME'.$i}</b></th><th width='25%'><span id='rval$i'>--</span></b></th><th width='25%'><span id='dayval$i'>--</span>";
        if (${'TYPE' . $i} != 'Sensor') {
            echo "${'UNIT'.$i}";
        }
        echo "</th><th width='25%'><span id='rtval$i'>--</span>";
        if (${'TYPE' . $i} != 'Sensor') {
            echo "${'UNIT'.$i}";
        }
        echo "</th></tr>";
    }
}
echo "
</tbody>
</table>
<br>&nbsp;";

if ($NUMIND > 0) { // indicators
    echo "
<table border=1 cellspacing=0 cellpadding=5 width=700 align='center'>
<tbody>";
    for ($i = 1; $i <= $NUMIND; $i++) {
        echo "<tr align='center'>
<th width='25%'>";
        if (${'INDPOOL' . $i} == 1) {
            echo "<b>${'INDNAME'.$i}</b></th><th width='25%'><b><span id='rival$i'>--</span> ${'INDUNIT'.$i}</b></th></tr>";
        } else if (${'INDPOOL' . $i} == 2) {
            echo "<b>${'INDNAME'.$i}</b></th><th width='25%'><b><span id='rival$i'>--</span></b></th></tr>";
        } else {
            echo "<b>${'INDNAME'.$i}</b></th><th width='25%'><span id='rival$i'>--</span></b></th></tr>";
        }
    }
    echo "
</tbody>
</table>
<br>&nbsp;
";
} // indicators

include("styles/" . $user_style . "/footer.php");
?>
