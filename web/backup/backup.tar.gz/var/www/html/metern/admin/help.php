<?php
include('../scripts/version.php');
include('../config/memory.php');
define('checkaccess', TRUE);
include('../config/config_main.php');
date_default_timezone_set($DTZ);
$nowUTC = strtotime(date("Ymd H:i:s"));

function convert($size)
{
    $unit = array(
        'b',
        'kb',
        'Mb',
        'Gb',
        'Tb',
        'Pb'
    );
    return @round($size / pow(1024, ($i = floor(log($size, 1024)))), 2) . $unit[$i];
}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>meterN Debug</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="../js/jqueryuicss/jquery-ui.css" type="text/css">
</head>
<body>
<table width="95%" height="80%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#FFFFFF" height="64"> 
  <td class="cadretopleft" width="128">&nbsp;<img src="../images/house48.png" width="48" height="48" alt="meterN"></td>
  <td class="cadretop" align="center"><b>meterN Debug</b></td>
  <td class="cadretopright" width="128" align="right"></td>
  </tr>
  <tr bgcolor="#CCCC66">
<td COLSPAN="3" class="cadre" height="10">
&nbsp;
</td></tr>  
<tr valign="top"> 
    <td COLSPAN="3" class="cadrebot" bgcolor="#d3dae2">
<!-- #BeginEditable "mainbox" -->
<?php
echo "
<br>
<table border=1 width='95%' cellspacing=0 cellpadding=5 align='center'>
<tr><td>
<b>$VERSION</b> Memory Usage: ";
echo memory_get_usage();
echo 'bytes - ';
echo convert(memory_get_usage(true));
echo "</td></tr>
<tr><td><b>tmpfs :</b><br>Make sure you only use a tmpfs, a temporary filesystem that resides in memory.
<br>";
$datareturn = null;
$datareturn = exec("df -h |grep $TMPFS | grep tmpfs");
if ($datareturn) {
    echo "<img src='../images/24/sign-check.png' width='24' height='24' border='0'> $TMPFS is ok ";
} else {
    echo "<img src='../images/24/sign-error.png' width='24' height='24' border='0'> $TMPFS is -NOT- OK ";
}
$datareturn = file_put_contents($TMPFS. '/test', 'test');
if ($datareturn) {
    echo "<img src='../images/24/sign-check.png' width='24' height='24' border='0'> ok to write";
	unlink($TMPFS. '/test');
} else {
    echo "<img src='../images/24/sign-error.png' width='24' height='24' border='0'> -NOT- OK to write";
}
echo "
</td></tr>
<tr><td valign='top'><b>Checking PHP :</b><br>
";
echo 'PHP version: ' . phpversion() . '<br>';
$input = '{ "jsontest" : " <br>Json extension loaded" }';
$val   = json_decode($input, true);
if ($val["jsontest"] != "") {
    echo "<img src='../images/24/sign-check.png' width='24' height='24' border='0'> Json extension loaded ";
} else {
    echo "<img src='../images/24/sign-error.png' width='24' height='24' border='0'> Json extension -NOT- loaded ";
}
if (!extension_loaded('calendar')) {
    echo "<img src='../images/24/sign-error.png' width='24' height='24' border='0'> Calendar extension -NOT- loaded ";
} else {
    echo "<img src='../images/24/sign-check.png' width='24' height='24' border='0'> Calendar extension loaded ";
}
if (!extension_loaded('curl')) {
    echo "<img src='../images/24/sign-error.png' width='24' height='24' border='0'> Curl extension -NOT- loaded ";
} else {
    echo "<img src='../images/24/sign-check.png' width='24' height='24' border='0'> Curl extension loaded ";
}
$ndday = date($DATEFORMAT . " H:i:s", $nowUTC);
echo "<br><br>You timezone is set to $DTZ ($ndday)";
if (ini_get('sendmail_path')) {
    echo '<br>Your sendmail_path is set to ' . ini_get('sendmail_path');
} else {
    echo '<br>Your sendmail_path is NOT set';
}
if (ini_get('open_basedir')) {
    echo '<br>open_basedir is set to ' . ini_get('open_basedir');
}
echo "
</td></tr>
<tr><td valign='top'><b>Hardware and communication apps. rights :</b><br>
Usually there is problem to access the communication ports such as /dev/ttyUSB* or /dev/ttyACM* as http user. <br>
Check what is your webserver's user. It's often 'http' but it might be 'www-data' or something else. <br>
The peripherals are usually owned by the 'uucp' or 'dialout' group, add your user: usermod -a -G uucp http<br>
Then verifiy with : groups http.<br>
<br>You also need to grant the access to your com. apps. Locate with 'whereis mycomapp' and chmod a+x /pathto/mycomapp.py.<br>
<br>Then you may need to restart php and your webserver. (e.g. systemctl restart php-fpm and systemctl restart nginx)
";
$datareturn = exec('whoami');
echo "<br><br>You are using as user : <b>$datareturn</b>, it belong to those groups: ";
$datareturn = exec("groups $datareturn");
echo "<b>$datareturn</b><br>
</td>
</tr>
<tr><td>
<b>Log error file :</b><br>";
if (!$DEBUG) {
    echo "<img src='../images/24/sign-warning.png' width='24' height='24' border='0'> The debug mode have to be enable in the main configuration";
}
echo "<br>
<textarea style='resize: none;background-color: #DCDCDC' cols='100' rows='10'>";
if (file_exists('../data/metern.err')) {
    $lines = file('../data/metern.err');
    foreach ($lines as $line_num => $line) {
        echo "$line";
    }
}
echo "</textarea>
</td></tr>
<tr><td>
<b>Memory ($MEMORY) :</b>
<br>";
$data     = file_get_contents($MEMORY);
$array   = json_decode($data, true);
print_r($array);
echo "<br><b>Live ($LIVEMEMORY) :</b>
<br>";
$data     = file_get_contents($LIVEMEMORY);
$array   = json_decode($data, true);
print_r($array);
echo "<br><b>Indicators ($ILIVEMEMORY) :</b>
<br>";
$data     = file_get_contents($ILIVEMEMORY);
$array   = json_decode($data, true);
print_r($array);
echo "
<br>
</td></tr>
</table>";
?>
<br>
<div align=center><INPUT TYPE='button' onClick="location.href='admin.php'" value='Back'></div>
<br>
<br>
<!-- #EndEditable -->
</td>
</tr>
</table>
</body>
</html>
