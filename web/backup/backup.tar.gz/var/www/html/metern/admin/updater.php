<?php
session_start();
$CURDIR  = $_SESSION['CURDIR'];
$SRVDIR  = $_SESSION['SRVDIR'];
$SELFDIR = $_SESSION['SELFDIR'];

if (empty($CURDIR) || !is_string($CURDIR) || empty($SRVDIR) || !is_string($SRVDIR) || basename(__DIR__) != '_INSTALL') {
    die('ERROR');
}
set_time_limit(0);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>meterN Updater</title>
</head>
<body>
<br>
<table width="70%" border=0 cellspacing=0 cellpadding=0 align="center">
<tr><td>
<?php
$error       = false;
$destination = 'temp.tar.gz';

$json   = file_get_contents('http://123solar.org/metern/latest_version.php');
$data   = json_decode($json, true);
$lastv  = $data['LASTVERSION'];
$source = $data['LINK'];
$md5    = $data['md5'];

define('checkaccess', TRUE);
include("$CURDIR/config/config_main.php");
date_default_timezone_set($DTZ);

function xcopy($source, $dest, $permissions)
{
    if (is_link($source)) { // Check for symlinks
        return symlink(readlink($source), $dest);
    }
    if (is_file($source)) { // Simple copy for a file
        return copy($source, $dest);
    }
    if (!is_dir($dest)) { // Make destination directory
        mkdir($dest, 0755);
    }
    $dir = dir($source); // Loop through the folder
    while (false !== $entry = $dir->read()) { // Skip pointers
        if ($entry == '.' || $entry == '..') {
            continue;
        }
        xcopy("$source/$entry", "$dest/$entry", $permissions); // Deep copy directories
    }
    $dir->close();
    return true;
}

// Check free space
$bytes     = disk_free_space(".");
$si_prefix = array(
    'B',
    'KB',
    'MB',
    'GB',
    'TB',
    'EB',
    'ZB',
    'YB'
);
$base      = 1024;
$class     = min((int) log($bytes, $base), count($si_prefix) - 1);
if ($bytes < 32000000) {
    $error = true;
    echo "ERROR: You should have at least 32 MB left on your disk<br>";
}

if (!$error) { // download
    ob_start();
    ob_flush();
    flush();
    
    $fp = fopen("$destination", 'w+');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "$source");
        //curl_setopt($ch, CURLOPT_BUFFERSIZE,128);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_NOPROGRESS, false);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_exec($ch);
        
        if (curl_getinfo($ch, CURLINFO_HTTP_CODE) != 200) {
            $error = true;
            echo "ERROR: Downloading";
        }
        curl_close($ch);
        fclose($fp);
        ob_flush();
        flush();
}

if (!$error) {
    exec("md5sum $destination", $output);
    $pieces = explode(' ', $output[0]);
    if (!$pieces[0] == $md5) {
        $error = true;
        echo "ERROR: md5sum<br>";
    }
}

if (!$error) {
    exec("tar -xzvf $destination -C $SRVDIR/_INSTALL/", $output, $return); // Return will return non-zero upon an error
    if ($return) {
        $error = true;
        echo "ERROR: Extracting<br>";
    }
}

if (!$error) {
    if (!xcopy("$CURDIR/data/", "$SRVDIR/_INSTALL/metern/data/", 0644)) {
        $error = true;
        echo "ERROR: Failed to import data<br>";
    }
    
    if (!xcopy("$CURDIR/config/", "$SRVDIR/_INSTALL/metern/config/", 0644)) {
        $error = true;
        echo "ERROR: Failed to import config<br>";
    }
}

if (!$error) {
    if (file_exists("$CURDIR/scripts/metern.pid")) {
        $pid     = (int) file_get_contents("$CURDIR/scripts/metern.pid");
        $command = exec("kill -9 $pid > /dev/null 2>&1 &");
        unlink("$CURDIR/scripts/metern.pid");
    }
}

if (!$error) { // Renaming
    $d = date('Ymd');
    exec("mv $CURDIR/ $CURDIR.$d/", $output, $return); // Return will return non-zero upon an error
    if ($return) {
        $error = true;
        echo "ERROR: mv $CURDIR/ $CURDIR.$d/<br>";
    }
}

if (!$error) { // Installing new
    exec("mv $SRVDIR/_INSTALL/metern/ $CURDIR/", $output, $return);
    if ($return) {
        $error = true;
        echo "ERROR: mv $SRVDIR/_INSTALL/metern/ $CURDIR/<br>";
    }
}

// Sync
exec("sync", $output, $return);

if (!$error) { // Compressing older
    $d   = date('Ymd');
    $rnd = rand();
    exec('tar -czPf mN_backup_' . $d . '_' . $rnd . ".tar.gz $CURDIR.$d/*", $output, $return);
    
    if ($return) {
        $error = true;
        echo "ERROR: tar -czPf mN_backup<br>";
    }
}

if (file_exists($destination)) {
	if (!unlink("$destination")) {
		echo "ERROR: Can't remove $destination<br>";
	}
}

if (!$error) {
    exec("rm -rf $CURDIR.$d", $output, $return);
    if ($return) {
        $error = true;
        echo "ERROR: rm -rf $CURDIR.$d<br>";
    }
}

if (!$error) {
    echo "<br>
<font color='#228B22'><b>Update complete.</b></font>
<br>For security reason move $SRVDIR/_INSTALL/mN_backup_" . $d . '_' . $rnd . ".tar.gz away from your webserver directory !
<br><br><u>Side notes:</u> Previous personal modifications weren't imported (eg: styles/)
<br>Please, also take this occasion to update your system.";
} else {
    echo "<br><font color='#8B0000'><b>The update didn't complete as expected !</b></font><br>
<br>CURDIR: $CURDIR
<br>SRVDIR: $SRVDIR
<br>SELFDIR: $SELFDIR";
}

session_destroy();
echo "<br><br><INPUT TYPE='button' onClick=\"location.href='$SELFDIR/'\" value='Go back to admin'>";
?>
</tr></td>
</table>
</body>
</html>
<?php
unlink(__FILE__);
?>
