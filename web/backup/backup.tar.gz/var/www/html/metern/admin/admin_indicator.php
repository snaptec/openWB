<?php
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" >
<title>meterN Administration</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="../js/jqueryuicss/jquery-ui.css" type="text/css">
</head>
<body>
<table width="95%" height="80%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#FFFFFF" height="64"> 
  <td class="cadretopleft" width="128">&nbsp;<img src="../images/house48.png" width="48" height="48" alt="meterN"></td>
  <td class="cadretop" align="center"><b>meterN Administration</font></td>
  <td class="cadretopright" width="128" align="right"></td>
  </tr>
  <tr bgcolor="#CCCC66">
<td align=right COLSPAN="3" class="cadre" height="10">
&nbsp;
</td></tr>  
<tr valign="top"> 
    <td COLSPAN="3" class="cadrebot" bgcolor="#d3dae2">
<!-- #BeginEditable "mainbox" -->
<?php
define('checkaccess', TRUE);
include('../config/config_main.php');
include('../config/config_indicator.php');

echo "<br>
<table border='0' cellspacing='5' cellpadding='0' width='80%' align='center'><tr><td>
<form method='POST' action='admin_indicator2.php' method='post'>
<div align=left>
Number of indicator(s) <input type='number' name='NUMINDx' value='$NUMIND' min='0' max='64' style='width:40px' onchange='this.form.submit()'>
</div>
</td></tr></table>
<div align=center>";
for ($ind_num = 1; $ind_num <= $NUMIND; $ind_num++) {
    echo "
<fieldset style='width:80%;'>
<legend><b>Indicator#$ind_num ${'INDNAME'.$ind_num}</b></legend>  
<table border='0' cellspacing='5' cellpadding='0' width='100%' align='center'>
<tr>
<td>Name <input type='text' name='INDNAMEx$ind_num' value='${'INDNAME'.$ind_num}' size=10></td>
<td>ID <input type='text' name='IDx$ind_num' value='${'INDID'.$ind_num}' size=10></td>
<td>
<select name='POOLx$ind_num' title='Choose if the command return a value (e.g.: Power in Watt) or a state for On/Off' onchange='this.form.submit()'";
    if (${'INDPOOL' . $ind_num} == 1) {
        echo "><option SELECTED value=1>Value</option><option value=2>State</option><option value=0>Disable</option>";
    } elseif (${'INDPOOL' . $ind_num} == 2) {
        echo "><option value=1>Value</option><option SELECTED value=2>State</option><option value=0>Disable</option>";
    } else {
        echo "><option value=1>Value</option><option value=2>State</option><option SELECTED value=0>Disable</option>";
    }
    echo "
</select>mode
</td>
<td>Command <input type='text' name='COMMANDx$ind_num' value='${'INDCOMMAND'.$ind_num}' size=25 title='May return a value or a state (e.g.: A water meter can give liters/min or tap on/off)'";
    if (${'INDPOOL' . $ind_num} == 0) {
        echo " disabled";
    }
    echo "> <input type='submit' name='bntsubmit$ind_num' value='Test command' onclick=\"if(!confirm('meterN will be stopped for this test, continue ?')){return false;}\"></td>
<td>
Unit <input type='text' name='UNITx$ind_num' value='${'INDUNIT'.$ind_num}' size=5>
</td>
</tr>
</table>
</fieldset><br>";
}
echo "<div align=center><INPUT TYPE='button' onClick=\"location.href='admin.php'\" value='Back'> <input type='submit' name='bntsubmit' value='Save config.'></div>
</form>";
?>
<br>
<br>
<!-- #EndEditable -->
          </td>
          </tr>
</table>
<br>
</body>
</html>
