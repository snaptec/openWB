<?php      
  header('Location: admin.php');      
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>meterN Administration</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" href="../styles/default/css/style.css" type="text/css">
<link rel="stylesheet" type="text/css" href="strength.css">
</head>
<body>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="strength.js"></script>
<script>
$(document).ready(function($) {
	
$('#myPassword').strength({
            strengthClass: 'strength',
            strengthMeterClass: 'strength_meter',
            strengthButtonClass: 'button_strength',
            strengthButtonText: 'Show password',
            strengthButtonTextToggle: 'Hide password'
        });
});
</script>
<table width="95%" height="80%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#FFFFFF" height="64"> 
  <td class="cadretopleft" width="128">&nbsp;<img src="../images/house48.png" width="48" height="48" alt="meterN"></td>
  <td class="cadretop" align="center"><b>meterN Administration</font></td>
  <td class="cadretopright" width="128" align="right">&nbsp;</td>
  </tr>
  <tr bgcolor="#CCCC66">
<td align=right COLSPAN="3" class="cadre" height="10">&nbsp;
</td></tr>  
<tr valign="top"> 
    <td COLSPAN="3" class="cadrebot" bgcolor="#d3dae2">
<!-- #BeginEditable "mainbox" -->
<?php
$CURDIR = dirname(dirname(__FILE__));
if(strstr($CURDIR, '_INSTALL')) {
	echo ("$CURDIR is an install directory !");
} else if (!isset($_SERVER["PHP_AUTH_USER"]) && !file_exists('../config/.htpasswd') && empty($_POST['login']) && empty($_POST['newpwd'])) {
    echo "<br><div align=center>
	<b>Thanks for using meterN !</b><br><br>
	Please, define a login and password :<br>
<br>
<form action='index.php' method='post'>
<table border=0 align='center' width='50%'>
<tr><td valign='top' align='right'>Login:</td><td align='left'><input type='text' name='login' value='admin'></td></tr>
<tr><td valign='top' align='right'>Password:</td><td align='left'><input id='myPassword' type='password' name='newpwd' value=''></td></tr>
<tr><td align=left colspan=2>
<br>By clicking 'OK', you explicitly agree with softwares, libraries and content licenses included in this package.
<br><br>meterN is released under the GNU GPLv3 license (General Public License).
This license allows you to freely integrate this library in your applications, modify the code and redistribute it in bundled packages as long as your application is also distributed with the GPL license.<br>
<br>The GPLv3 license description can be found at <a href='http://www.gnu.org/licenses/gpl.html'>http://www.gnu.org/licenses/gpl.html</a> <br>
<br>Highcharts, the javascript charting library bundled in this package is free for non-commercial use only. <a href='http://highcharts.com'>http://highcharts.com</a><br>
</tr>
</td>
<tr><td align=center colspan=2><br><input type='submit' value='OK'> <input type='button' onClick=\"location.href='http://www.wikipedia.org'\" value='Cancel'></td>
</tr></table>
</form>
";
} elseif (!file_exists('../config/.htpasswd') && !isset($_SERVER["PHP_AUTH_USER"]) && !empty($_POST['login']) && !empty($_POST['newpwd'])) {
    $pw_file  = '../config/.htpasswd';
    $login    = trim($_POST['login']);
    $newpwd   = trim($_POST['newpwd']);
    $password = crypt($newpwd, base64_encode($newpwd));
    $pw_line  = "$login:$password\n";
    $pf       = fopen($pw_file, "w");
    fwrite($pf, $pw_line);
    fclose($pf);
    $doc_dir  = dirname(dirname(__FILE__));
    $acc_file = '../config/.htaccess';
    $af       = fopen($acc_file, "w");
    $new_acc  = "AuthUserFile $doc_dir/config/.htpasswd\n";
    $new_acc .= "AuthGroupFile /dev/null\n";
    $new_acc .= "AuthName \"meterN Password Protected Area\"\n";
    $new_acc .= "AuthType Basic\n";
    $new_acc .= "require valid-user\n";
    fwrite($af, $new_acc);
    fclose($af);
    echo "<br><div align=center><font color='#228B22'><b>Password is saved for the $login user, don't forget it</b></font>
<br><br>
<INPUT TYPE='button' onClick=\"location.href='index.php'\" value='Continue'>
</div>";
} elseif (file_exists('../config/.htpasswd') && !isset($_SERVER["PHP_AUTH_USER"])) {
    $doc_dir = dirname(__FILE__);
    echo "<br><div align=center><img src='../images/24/sign-warning.png' width='24' height='24' border='0'><font color='#8B0000'><b> Your webserver don't currently allow HTTP authentication. It is vulnerable !</b></font><br><br>
	Please configure your webserver : ";
    echo $_SERVER['SERVER_NAME'];
    echo " (";
    echo $_SERVER['SERVER_SOFTWARE'];
    echo ") and then, refresh your browser.<br>Credentials have been created as config/.htpasswd <br></div>";
} elseif (isset($_SERVER["PHP_AUTH_USER"])) {
    header('Location: admin.php');
}
?>
<br>
<br>
          <!-- #EndEditable -->
          </td>
          </tr>
</table>
</body>
</html>
