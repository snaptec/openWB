<?php
include('styles/globalheader.php');
include('config/config_main.php');

$output = array();
$dir    = 'data/meters/';
$output = glob($dir . '*.csv');
$cnt    = count($output);

if ($cnt > 1) {
    if (!empty($_POST['meter'])) {
        $meter = $_POST['meter'];
    } else {
        $meter = 1;
    }
    
    echo "<table width='95%' border=0 align=center cellpadding=8>
<tr><td>
<form method='POST' action='readings.php'>
$lgCHOOSEMET: <select name='meter' onchange='this.form.submit()'>";
    for ($i = 1; $i <= $NUMMETER; $i++) {
        include("config/config_met$i.php");
        if ($meter == $i) {
            echo "<option value='$i' SELECTED>";
        } else {
            echo "<option value='$i'>";
        }
        echo "${'METNAME'.$i}</option>";
    }
    echo "</select> 
</form>
";
?>
</td></tr>
</table>

<script type="text/javascript">
$(document).ready(function() {
Highcharts.setOptions({
global: {useUTC: true},
lang: {
decimalPoint: '<?php
    echo $DPOINT;
?>',
thousandsSep: '<?php
    echo $THSEP;
?>',
months: ['<?php
    for ($i = 1; $i < 12; $i++) {
        echo "$lgMONTH[$i]','";
    }
    echo $lgMONTH[12];
?>'],
shortMonths: ['<?php
    for ($i = 1; $i < 12; $i++) {
        echo "$lgSMONTH[$i]','";
    }
    echo $lgSMONTH[12];
?>'],
weekdays: ['<?php
    for ($i = 1; $i < 7; $i++) {
        echo "$lgWEEKD[$i]','";
    }
    echo "$lgWEEKD[7]'],
drillUpText: '$lgDRILLUP',
loading: '$lgLOAD',
printChart: '$lgPRINT',
resetZoom: '$lgRESETZ'
";
?>
}
});

var defaultTitle = "<?php
    echo "$lgCONSUTITLE: ${'METNAME'.$meter}";
?>", prevPointTitle = null;

var Mychart, options = {
        chart: {
                type: 'column',
                backgroundColor: null,
				events: {
					drilldown: function (e) {
						this.setTitle({
							text: e.point.title
						});
						if (!prevPointTitle) {
							prevPointTitle = e.point.title;
						}
					},
					drillup: function (e) {
						if ( !! this.series[0].drilldownLevel) {
							this.setTitle({
								text: defaultTitle
							});
							prevPointTitle = null;
						} else {
							this.setTitle({
								text: prevPointTitle
							});
						}
					}
				},
            },
			title: {
				text: defaultTitle
			},
            subtitle: {text: '<?php
    echo "$lgCONSUSUBTITLE";
?>'},
            xAxis: {
            type: 'datetime'
            },
            yAxis: {
    		min: 0,
    		minPadding: 0,
			title: {text: '<?php
    echo "${'UNIT'.$meter}";
?>'}
            },
		plotOptions: {
			series: {
				borderWidth: 1,
				dataLabels: {
					enabled: true,
					formatter:function() 
					{
						return Highcharts.numberFormat(this.y,<?php
    if (${'TYPE' . $meter} == 'Elect') {
        echo "0) + ' kWh';";
    } else {
        echo "${'PRECI'.$meter}) + ' ${'UNIT'.$meter}';";
    }
?>

					}
				},
				point: {
					events: {
						click: function(event) {
							var point = this;
								if (point.y) {
									if (confirm('<?php
    echo $lgSHOWDETAIL;
?>')) {
									window.location = 'detailed.php?<?php
    echo ${'METNAME' . $meter};
?>=on&date2='+this.x;
									}
								}
						}
					}
				}
			},
			column: {
			  color: "<?php
    echo "#${'COLOR'.$meter}";
?>",
			  cursor: 'pointer'
			}
		},
        tooltip: {
			formatter: function() {
				if (Mychart.series[0].options._levelNumber==1) {
				s= '<b>' + Highcharts.dateFormat('%B %Y', this.x);
				} else if (Mychart.series[0].options._levelNumber==2) {
				s= '<b>' + Highcharts.dateFormat('%a. %d %B %Y', this.x);	
				} else {
				s= '<b>' + Highcharts.dateFormat('%Y', this.x);
				}
			s+= '</b><br><b>'+ Highcharts.numberFormat(this.y,<?php
    if (${'TYPE' . $meter} == 'Elect') {
        echo "2) + ' kWh</b>';";
    } else {
        echo "${'PRECI'.$meter}) + ' ${'UNIT'.$meter}</b>';";
    }
    if (${'PRICE' . $meter} > 0) {
        echo "
		    s += ' (' + Highcharts.numberFormat((this.y*${'PRICE'.$meter}),1) + '$CURS)';
		";
    }
?>
	return s;
			
			}
		 },		
  exporting: {
  filename: 'meterN-chart',
  width: 1200
  },
  credits: {
  enabled: false
  },
    series: [],
    drilldown: []
 };
<?php
    $destination = "programs/programreadings.php";
    echo "
var meter = '$meter';
Mychart= Highcharts.chart('container',options);

Mychart.showLoading();
$.getJSON('$destination', { meter: meter }, function(JSONResponse) {
  options.series = JSONResponse.series;
  options.drilldown = JSONResponse.drilldown;
  Mychart= Highcharts.chart('container',options);
  Mychart.hideLoading();
});
});";
    
    echo "
</script>";
} else {
    echo '<br>No data';
}
echo "
<table width='100%' border=0 align=center cellpadding=0>
<tr><td><div id='container' style='width: 95%; height: 450px'></div></td></tr>
</table>
";

include("styles/" . $user_style . "/footer.php");
?>
