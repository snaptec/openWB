<?php
// Load configuration
if (isset($_SERVER['REMOTE_ADDR'])) {
    die('Direct access not permitted');
}

if (get_current_user() == 'root') {
    //die('Abording. meterN cannot be as root');
}
// Few checks
$input = '{ "jsontest" : " <br>Json extension loaded" }';
$val   = json_decode($input, true);
if ($val["jsontest"] != "") {
} else {
    die("/!\ Json extension -NOT- loaded. Abording, please update php.ini.\n");
}

define('checkaccess', TRUE);
if (is_readable('../config/config_main.php')) {
    include('../config/config_main.php');
} else {
    die("Abording. Can't open config_main.php.\n");
}
if (is_readable('../config/config_indicator.php')) {
    include('../config/config_indicator.php');
} else {
    die("Abording. Can't open config_indicator.php.\n");
}
if (is_readable('../config/memory.php')) {
    include('../config/memory.php');
} else {
    die("Abording. Can't open memory.php.\n");
}

if (file_exists($MEMORY)) {
    $data     = file_get_contents($MEMORY);
    $memarray = json_decode($data, true);
}

date_default_timezone_set($DTZ);
// Date check
$output = array();
$output = glob('../data/csv/*.csv');
sort($output);
$xdays = count($output);

$nowutc = strtotime(date('Ymd H:i:s'));
if ($xdays > 1) {
    $lastlog    = $output[$xdays - 1];
    $lines      = file($lastlog);
    $contalines = count($lines);
    $array      = preg_split('/,/', $lines[$contalines - 1]);
    $date1      = substr($output[$xdays - 1], -12);
    
    $year   = (int) substr($date1, 0, 4);
    $month  = (int) substr($date1, 4, 2);
    $day    = (int) substr($date1, 6, 2);
    $hour   = (int) substr($array[0], 0, 2);
    $minute = (int) substr($array[0], 3, 2);
    
    $epochdate = strtotime($year . "-" . $month . "-" . $day . " " . $hour . ":" . $minute);
} else {
    $epochdate = 1242975600;
}
$i = 1;
while ($nowutc < $epochdate) {
    $nowutc = strtotime(date('Ymd H:i:s'));
    echo "Computer time is not correct, trying again in $i sec\n";
    sleep("$i");
    $i++;
    if ($i > 1200) {
        die("Abording..\n");
    }
}

// Initialize variables
$minlist = array(
    '00',
    '05',
    '10',
    '15',
    '20',
    '25',
    '30',
    '35',
    '40',
    '45',
    '50',
    '55'
);

$DATADIR = dirname(dirname(__FILE__)) . '/data';
$DELAY *= 1000;

function pushover($uid, $title, $msg) // Push-over
{
    curl_setopt_array($ch = curl_init(), array(
        CURLOPT_URL => 'https://api.pushover.net/1/messages.json',
        CURLOPT_TIMEOUT => 10,
        CURLOPT_POSTFIELDS => array(
            'token' => 'BCZigaCQktVT4zR1xmpZ3iXsmkbm59',
            'user' => $uid,
            'message' => $msg
        )
    ));
    curl_exec($ch);
    curl_close($ch);
}

function rpinotify($token, $msg) // RpiNotify
{
    $msg = str_replace('/', '-', $msg); //bug
    $msg = rawurlencode($msg);
    $url = 'http://api.rpinotify.it/notification/' . $token . '/text/' . $msg;
    $ch  = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_exec($ch);
    curl_close($ch);
}

function logevents($stringData) // Log to events
{
    $dir = dirname(dirname(__FILE__)) . '/data';
    $stringData .= file_get_contents($dir . '/events.txt');
    file_put_contents($dir . '/events.txt', $stringData);
}

function isvalid($id, $datareturn) //  IEC 62056 data set structure
{
    $regexp = "/^$id\(-?[A-z0-9\.]+\*[A-z0-9³²%°]+\)$/i"; //ID(VALUE*UNIT)
    if (preg_match($regexp, $datareturn)) {
        $datareturn = preg_replace("/^$id\(/i", '', $datareturn, 1); // VALUE*UNIT)
        $datareturn = preg_replace("/\*[A-z0-9³²%°]+\)$/i", '', $datareturn, 1); // VALUE
    } else {
        $datareturn = null;
    }
    return $datareturn;
}

// Meters config
for ($i = 1; $i <= $NUMMETER; $i++) {
    if (is_readable("../config/config_met$i.php")) {
        include("../config/config_met$i.php");
    } else {
        die("Abording. Can't open config_met$i.php.\n");
    }
    if (!isset($memarray["msgflag$i"])) {
        $memarray["msgflag$i"] = 0;
    }
    $livememarray['UTC']               = strtotime(date('Ymd H:i:s'));
    $livememarray["${'METNAME'.$i}$i"] = 0;
    ${'comlost' . $i}                  = false;
}
if (!isset($memarray['5minflag'])) {
    $memarray['5minflag'] = false;
}

/////  Main memory
$data = json_encode($memarray);
file_put_contents($MEMORY, $data);
/////  Live memory
$data = json_encode($livememarray);
file_put_contents($LIVEMEMORY, $data);
?>
