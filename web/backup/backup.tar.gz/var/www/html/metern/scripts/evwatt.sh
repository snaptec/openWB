#!/bin/bash
lkwh=$(cat /var/www/html/openWB/ramdisk/llkwh)
llwh=$(echo $lkwh *1000 |bc)
printf "EV(" && echo $llwh | tr -d '\n' && printf "*W)"
