#!/bin/bash
lkwh=$(cat /var/www/html/openWB/ramdisk/llkwh)
re='^-?[0-9]+$'
if [ -f /var/www/html/openWB/ramdisk/llkwhs1 ]; then
	llkwhs1=$(cat /var/www/html/openWB/ramdisk/llkwhs1)
	if ! [[ $llkwhs1 =~ $re ]] ; then
		llwkhs1="0"
	fi
	llkwhs=$(echo $lkwh + $llkwhs1 |bc)
fi
llwh=$(echo $llkwhs *1000 |bc)
printf "EV(" && echo $llwh | tr -d '\n' && printf "*W)"
