#!/bin/bash

bezugkwh=$(cat /var/www/html/openWB/ramdisk/bezugkwh)



printf "EVU(" && echo $bezugkwh | tr -d '\n' && printf "*W)"
