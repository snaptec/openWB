#!/bin/bash


re='^[0-9]+$'
einspeisew=$(cat /var/www/html/openWB/ramdisk/wattbezug)        
bezugw=$(echo $einspeisew *-1 |bc)
if ! [[ $bezugw =~ $re ]] ; then
	bezugw=0
fi

printf "Einspeisung(" && echo $bezugw |tr -d '\n' && printf "*W)"
