#!/bin/bash
printf "EV(" && cat /var/www/html/openWB/ramdisk/llkombiniert |tr -d '\n' && printf "*W)"
