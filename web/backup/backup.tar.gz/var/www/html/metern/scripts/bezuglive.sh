#!/bin/bash


re='^[0-9]+$'
pvwatt=$(cat /var/www/html/openWB/ramdisk/pvwatt)
bezugw=$(cat /var/www/html/openWB/ramdisk/wattbezug)        
#if ! [[ $bezugw =~ $re ]] ; then
#	bezugw=0
#fi
bezugww=$(echo $pvwatt + $bezugw |bc)
printf "EVU(" && echo $bezugww |tr -d '\n' && printf "*W)"
