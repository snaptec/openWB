#!/bin/bash
printf "PV(" && cat /var/www/html/openWB/ramdisk/pvwatt |tr -d '\n' && printf "*W)"
