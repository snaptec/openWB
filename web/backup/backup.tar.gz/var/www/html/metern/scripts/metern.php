<?php
include('loadcfg.php');
while (true) { // To infinity ... and beyond!
    for ($metnum = 1; $metnum <= $NUMMETER; $metnum++) { // Meters/Sensors pooling
        ///// Main memory
        $data        = file_get_contents($MEMORY);
        $memarray1st = $data;
        $memarray    = json_decode($data, true);
        
        ///// Live memory
        $data         = file_get_contents($LIVEMEMORY);
        $livememarray = json_decode($data, true);
        
        if (!${'SKIPMONITORING' . $metnum} && ${'LIVEPOOL' . $metnum} != 0) {
            $val = null;
            exec(${'LIVECOMMAND' . $metnum}, $datareturn);
            $datareturn = trim(implode($datareturn));
            $val        = isvalid(${'LID' . $metnum}, $datareturn);
            if (isset($val)) {
                $livememarray['UTC'] = strtotime(date('Ymd H:i:s'));
            } else {
                $val                 = 0;
                $livememarray['UTC'] = '0';
                if ($LOGCOM) {
                    $now = date($DATEFORMAT . ' H:i:s');
                    logevents("$now\tCommunication error with #$metnum ${'METNAME'.$metnum}\n\n");
                }
            }
        } else {
            $val                 = 0;
            $livememarray['UTC'] = strtotime(date('Ymd H:i:s'));
        }
        
        $livememarray["${'METNAME'.$metnum}$metnum"] = $val; // Live value or state
        
        $minute   = date('i');
        $fiveflag = (bool) $memarray['5minflag'];
        
        if (in_array($minute, $minlist) && !$memarray['5minflag']) { // 5 min jobs
            $memarray['5minflag'] = true;
            $today                = date('Ymd');
            
            for ($i = 1; $i <= $NUMMETER; $i++) { // For each meters
                $datareturn = null;
                $matches    = array();
                $giveup     = 0;
                $lastval    = null;
                
                if (!${'SKIPMONITORING' . $i}) {
                    while (!isset($lastval) && $giveup < 3) { // Try 3 times
                        exec(${'COMMAND' . $i}, $datareturn);
                        $datareturn = trim(implode($datareturn));
                        $lastval    = isvalid(${'ID' . $i}, $datareturn);
                        sleep($giveup);
                        $giveup++;
                    }
                    if ($giveup > 2) {
                        $now = date($DATEFORMAT . ' H:i:s');
                        logevents("$now\tMissing #$i ${'METNAME'.$i} 5' sample\n\n");
                    }
                    if ((${'NORESPM' . $i}) && !isset($lastval) && !${'comlost' . $i}) {
                        ${'comlost' . $i} = true;
                        $now              = date($DATEFORMAT . ' H:i:s');
                        $stringData       = "$now\tConnection lost with #$i ${'METNAME'.$i}\n\n";
                        logevents($stringData);
                        
                        if (!empty(${'POUKEY' . $i})) {
                            $pushover = pushover(${'POUKEY' . $i}, "#i ${'METNAME' . $i} Warning", $stringData);
                        }
                        if (!empty(${'RPITOK' . $i})) {
                            $rpinotify = rpinotify(${'RPITOK' . $i}, "meterN $stringData");
                        }
                    }
                }
                
                if ($i == 1) {
                    $PCtime      = date('H:i');
                    $stringData5 = "$PCtime";
                }
                $stringData5 .= ",$lastval";
                if (${'TYPE' . $i} != 'Sensor') {
                    $memarray["Totalcounter$i"] = $lastval;
                }
            } // For each meters
            
            $stringData5 .= "\r\n";
            
            if (file_exists($DATADIR . "/csv/$today.csv")) {
                file_put_contents($DATADIR . "/csv/$today.csv", $stringData5, FILE_APPEND);
            } else { // Midnight or startup
                $yesterday = date('Ymd', time() - (60 * 60 * 24) + 30); // yesterday
                if ($PCtime == '00:00' && file_exists($DATADIR . "/csv/$yesterday.csv")) {
                    file_put_contents($DATADIR . "/csv/$yesterday.csv", $stringData5, FILE_APPEND);
                }
                
                $stringData = "Time"; // Header line
                for ($i = 1; $i <= $NUMMETER; $i++) {
                    $stringData .= ",${'METNAME'.$i}(${'UNIT'.$i})";
                    ${'comlost' . $i} = false;
                }
                $stringData .= "\r\n";
                $stringData .= "$stringData5";
                file_put_contents($DATADIR . "/csv/$today.csv", $stringData, FILE_APPEND);
                
                $csvlist = glob($DATADIR . '/csv/*.csv');
                sort($csvlist);
                $xdays = count($csvlist);
                
                if ($xdays > 1) { // previous day
                    $lines      = file($csvlist[$xdays - 2]);
                    $contalines = count($lines);
                    $csvdate1   = substr($csvlist[$xdays - 2], -12, 8);
                    $year       = (int) substr($csvlist[$xdays - 2], -12, 4); // For new year
                    for ($i = 1; $i <= $NUMMETER; $i++) {
                        $memarray["msgflag$i"] = false; // clear msgflag
                        if (${'TYPE' . $i} != 'Sensor') {
                            $val_last  = null;
                            $val_first = null;
                            $j         = 0;
                            while (!isset($val_first)) {
                                $j++;
                                $array     = preg_split('/,/', $lines[$j]);
                                $val_first = isset($array[$i]) ? trim($array[$i]) : '';
                                if ($val_first == '') { // if skipped
                                    $val_first = null;
                                }
                                if ($j == $contalines - 1) {
                                    $val_first = 0; // didn't find any prev. first value
                                }
                            }
                            $j = 0;
                            while (!isset($val_last)) {
                                $j++;
                                $array    = preg_split('/,/', $lines[$contalines - $j]);
                                $val_last = isset($array[$i]) ? trim($array[$i]) : '';
                                $val_last = isset($array[$i]) ? trim($array[$i]) : '';
                                if ($val_last == '') {
                                    $val_last = null;
                                }
                                if ($j == $contalines - 1) {
                                    $val_last = 0;
                                }
                            }
                            settype($val_last, 'float');
                            settype($val_first, 'float');
                            
                            if ($val_first <= $val_last) {
                                $val_last -= $val_first;
                            } else { // counter pass over
                                $val_last += ${'PASSO' . $i} - $val_first;
                            }
                            $val_last   = round($val_last, ${'PRECI' . $i});
                            $stringData = "$csvdate1";
                            $stringData .= ",$val_last\r\n";
                            
                            file_put_contents($DATADIR . '/meters/' . $i . ${'METNAME' . $i} . $year . '.csv', $stringData, FILE_APPEND);
                        }
                        // Reports
                        $adate = date('d');
                        if ($adate == '01' && !empty(${'EMAIL' . $i})) {
                            $y_year      = date('Y', time() - 60 * 60 * 24); // yesterday
                            $y_month     = date('m', time() - 60 * 60 * 24);
                            $mlines      = file($DATADIR . '/meters/' . $i . ${'METNAME' . $i} . $y_year . '.csv');
                            $mcontalines = count($mlines);
                            $j           = 0;
                            for ($line_num = 0; $line_num < $mcontalines; $line_num++) {
                                $array = preg_split('/,/', $mlines[$line_num]);
                                $month = substr($array[0], 4, 2);
                                if ($month == $y_month) {
                                    $month         = substr($array[0], 4, 2);
                                    $day           = substr($array[0], 6, 2);
                                    $dayname[$j]   = date($DATEFORMAT, mktime(0, 0, 0, $month, $day, $y_year));
                                    $conso_day[$j] = $array[1];
                                    $conso_day[$j] = round($conso_day[$j], ${'PRECI' . $i});
                                    $j++;
                                }
                            }
                            $conso_month = number_format(array_sum($conso_day), ${'PRECI' . $i}, $DPOINT, $THSEP);
                            $cnt         = count($dayname);
                            $msg         = "${'METNAME'.$i}\t (${'UNIT'.$i})\r\n";
                            for ($j = 0; $j < $cnt; $j++) {
                                $conso_day[$j] = number_format($conso_day[$j], ${'PRECI' . $i}, $DPOINT, $THSEP);
                                $msg .= "$dayname[$j]\t";
                                $msg .= "$conso_day[$j]\r\n";
                            }
                            $msg .= "\r\n";
                            $msg .= "$conso_month ${'UNIT'.$i} on $y_month $y_year\r\n---\r\n";
                            mail("${'EMAIL'.$i}", "meterN: ${'METNAME'.$i} Monthly $y_month report", $msg, "From: meterN <${'EMAIL'.$i}>");
                        } // Reports
                    }
                } // previous day
                
                if ($KEEPDDAYS != 0 || $AMOUNTLOG != 0) { // Morning cleanup
                    $stringData = date($DATEFORMAT . ' H:i:s') . "\tClean up ";
                    if ($AMOUNTLOG != 0) {
                        $lines = file('../data/events.txt');
                        $cnt   = count($lines);
                        if ($cnt >= $AMOUNTLOG) {
                            $now = date($DATEFORMAT . ' H:i:s');
                            array_splice($lines, $AMOUNTLOG);
                            $file2 = fopen('../data/events.txt', 'w');
                            fwrite($file2, implode('', $lines));
                            fclose($file2);
                            $stringData .= 'events log ';
                        }
                    }
                    if ($KEEPDDAYS != 0) {
                        if ($xdays > $KEEPDDAYS) {
                            $i = 0;
                            while ($i < $xdays - $KEEPDDAYS) {
                                unlink($csvlist[$i]);
                                $i++;
                            }
                            $stringData .= "purging $i csv";
                        }
                    }
                    logevents($stringData . "\n\n");
                } // Morning clean up 
            } // Midnight
            
            $lines      = file($DATADIR . "/csv/$today.csv");
            $contalines = count($lines);
            if ($contalines > 2) { // Consumption/production sensor check
                for ($i = 1; $i <= $NUMMETER; $i++) {
                    $msgflag = (bool) $memarray["msgflag$i"];
                    if (!$msgflag) {
                        $val_last  = null;
                        $val_first = null;
                        $array     = preg_split('/,/', $lines[1]);
                        if (isset($array[$i])) {
                            $val_first = trim($array[$i]);
                            settype($val_first, 'float');
                        }
                        $array = preg_split('/,/', $lines[$contalines - 1]);
                        if (isset($array[$i])) {
                            $val_last = trim($array[$i]);
                            settype($val_last, 'float');
                        }
                        
                        if (!empty($val_first) && !empty($val_last) && ${'TYPE' . $i} != 'Sensor') { // Meter
                            if ($val_first <= $val_last) {
                                $val_last -= $val_first;
                            } else { // counter pass over
                                $val_last += ${'PASSO' . $i} - $val_first;
                            }
                        }
                        
                        if (!empty($val_first) && !empty($val_last) && $val_last > ${'WARNCONSOD' . $i} && ${'WARNCONSOD' . $i} != 0 && !${'SKIPMONITORING' . $i}) {
                            $memarray["msgflag$i"] = true;
                            
                            $now        = date($DATEFORMAT . ' H:i:s');
                            $val_last   = number_format($val_last, ${'PRECI' . $i}, $DPOINT, $THSEP);
                            $stringData = "$now\t#$i ${'METNAME'.$i} ";
                            if (${'PROD' . $i} == 1) {
                                $stringData .= "production reach $val_last ${'UNIT'.$i}\n\n";
                            } elseif (${'PROD' . $i} == 2) {
                                $stringData .= "consumption reach $val_last ${'UNIT'.$i}\n\n";
                            } else {
                                $stringData .= "reach $val_last ${'UNIT'.$i}\n\n";
                            }
                            logevents($stringData);
                            
                            if (!empty(${'POUKEY' . $i})) {
                                $pushover = pushover(${'POUKEY' . $i}, "#i ${'METNAME' . $i} Warning", $stringData);
                            }
                            if (!empty(${'RPITOK' . $i})) {
                                $rpinotify = rpinotify(${'RPITOK' . $i}, "meterN Warning $stringData");
                            }
                        }
                    }
                }
            } // Consumption/prod check
            include('../config/config_trigger.php');
        } // 5 min 
        
        if (!in_array($minute, $minlist) && $memarray['5minflag']) { // Run once every 1,6,11,16,..
            $memarray['5minflag'] = false; // Reset 5minflag
        }
        
        $data = json_encode($memarray);
        if ($data != $memarray1st) { // Reduce write
            $data = json_encode($memarray);
            file_put_contents($MEMORY, $data);
        }
        
        $data = json_encode($livememarray);
        file_put_contents($LIVEMEMORY, $data);
    } // End meters pooling
    
    if ($NUMIND > 0) { // Indicators
        for ($i = 1; $i <= $NUMIND; $i++) {
            if (${'INDPOOL' . $i} != 0) {
                $val = 0;
                exec(${'INDCOMMAND' . $i}, $datareturn);
                $datareturn = trim(implode($datareturn));
                $val        = isvalid(${'INDID' . $i}, $datareturn);
                if (isset($val)) {
                    $ilivememarray["${'INDNAME'.$i}$i"] = $val; // Live value or state
                }
            }
        }
        
        $data = json_encode($ilivememarray);
        file_put_contents($ILIVEMEMORY, $data);
    } // end of indicator
    usleep($DELAY);
} // infinity
?>
