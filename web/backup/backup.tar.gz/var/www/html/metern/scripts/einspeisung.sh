#!/bin/bash

einspeisungkwh=$(cat /var/www/html/openWB/ramdisk/einspeisungkwh)

printf "Einspeisung(" && echo $einspeisungkwh | tr -d '\n' && printf "*Wh)"
