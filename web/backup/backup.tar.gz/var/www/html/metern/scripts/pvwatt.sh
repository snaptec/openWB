#!/bin/bash
pvwh=$(cat /var/www/html/openWB/ramdisk/pvkwh)
printf "PV(" && echo $pvwh | tr -d '\n' && printf "*W)"

