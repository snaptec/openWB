<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" height="90%">
  <tr bgcolor="#6CB01F"> 
    <td class="cadretopleft" width="128"><img src="styles/<?php echo $user_style;?>/images/floral80200.jpg" width="200" height="80" alt="meterN"></td>
  <td class="cadretop" align="center"><font size="+1" color="#FFFFFF"><b><?php echo "$TITLE";?></b></font><br><font size="-1" color="#DDD"><?php echo "$SUBTITLE";?></font></font></td>
  <td class="cadretopright" width="128" align="right">
  <?php include("styles/selectlanguages.php");?>
  </td>
  </tr>
  <tr valign="top"> 
    <td height="100%" COLSPAN="3"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" height="100%">
        <tr valign="top"> 
          <td width="128" class="cadrebotleft"  bgcolor="#DDD" height="98%"> 
            <div class="menu"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="5" align="left">
                <tr><td></td></tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href="index.php"><?php echo "$lgMINDEX";?></a></font></td>
                </tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href="detailed.php"><?php echo "$lgMDETAILED";?></a></font></td>
                </tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href="readings.php"><?php echo "$lgMREAD";?></a></font></td>
                </tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href='comparison.php'><?php echo $lgMCOMPARISON;?></a></font></td>
                </tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href="dashboard.php"><?php echo "$lgMDASH";?></a></font></td>
                </tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href="info.php"><?php echo "$lgMINFO";?></a></font></td>
                </tr>
		<tr><td><hr noshade size=1></td></tr>
                <tr> 
                  <td><font class="menu"><img src="styles/<?php echo $user_style;?>/images/arr_grey.gif" width="15" height="11"> <a href="../123solar">123Solar</a></font></td>
                </tr>
              </table>
            </div>
          </td>
          <td class="cadrebotright" bgcolor="#EEE" height="98%"> 
            <table border="0" cellspacing="10" cellpadding="0" width="100%" height="100%" align="center">
              <tr valign="top"> 
                <td> <!-- #BeginEditable "mainbox" -->
