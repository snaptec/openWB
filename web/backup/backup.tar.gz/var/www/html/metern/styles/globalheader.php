<?php
define('checkaccess', TRUE);
include('config/config_main.php');
date_default_timezone_set($DTZ);
if (!empty($_POST['user_lang']) && is_string($_POST['user_lang'])) {
    $user_lang = htmlspecialchars($_POST['user_lang'], ENT_QUOTES, "UTF-8");
    setcookie('user_lang', $_POST['user_lang'], strtotime('+5 year'));
} else {
    if (isset($_COOKIE['user_lang'])) {
        $user_lang = $_COOKIE['user_lang'];
    } elseif (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
        switch ($lang) {
            case 'en':
                $user_lang = 'English';
                break;
            case 'fr':
                $user_lang = 'Français';
                break;
            case 'it':
                $user_lang = 'Italiano';
                break;
            default:
                $user_lang = 'English';
                break;
        }
        setcookie('user_lang', $user_lang, strtotime('+5 year'));
    } else {
        setcookie('user_lang', 'English', strtotime('+5 year'));
        $user_lang = 'English';
    }
}
include('languages/' . $user_lang . '.php');

if (!empty($_POST['user_style']) && is_string($_POST['user_style']) && file_exists('styles/' . $_COOKIE['user_style'])) {
    $user_style = htmlspecialchars($_POST['user_style'], ENT_QUOTES, 'UTF-8');
    setcookie('user_style', $user_style, strtotime('+5 year'));
} elseif (isset($_COOKIE['user_style']) && file_exists('styles/' . $_COOKIE['user_style'])) {
    $user_style = $_COOKIE['user_style'];
} else {
    $user_style = 'default';
    setcookie('user_style', 'default', strtotime('+5 year'));
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php
echo "$TITLE";
?></title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link href="favicon.ico" rel="icon" type="image/x-icon">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="js/jqueryuicss/jquery-ui.css" type="text/css">
<script type="text/javascript" src="js/highcharts.js"></script>
<script type="text/javascript" src="js/highcharts-more.js"></script>
<script type="text/javascript" src="js/drilldown.js"></script>
<script type="text/javascript" src="js/exporting.js"></script>
<link rel="stylesheet" href="styles/<?php
echo $user_style;
?>/css/style.css" type="text/css">
<?php
include('styles/yourheader.php');
?>
</head>
<?php
if ($DEBUG) {
    echo "(Debug mode shouldn't be left permanently)";
}
include('styles/' . $user_style . '/header.php');
?>
