<?php // Language selection
$currentFile = $_SERVER["PHP_SELF"];
$parts = Explode('/', $currentFile);
$currentFile=$parts[count($parts) - 1];

$dir = 'languages/';
$output = glob($dir . "*.php");
sort($output);
$xlang =count($output);

echo"<form method=\"POST\" action=\"$currentFile\">
<select name='user_lang' onchange='this.form.submit()'>";
for ($i=0;$i<$xlang;$i++){ 
$output[$i] = str_replace("$dir", '', "$output[$i]");
$option = substr_replace($output[$i],"",-4);
  if ($user_lang==$option) {
  echo "<option selected>";
  } else {
  echo "<option>";
  }
echo "$option</option>";
}
echo "</select>&nbsp;
</form>
";
?>
