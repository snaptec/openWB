<body>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#FFFFFF" height="64"> 
  <td class="cadretopleft" width="128">&nbsp;<img src="styles/default(home)/images/house48.png" width="48" height="48" alt="meterN"></td>
  <td class="cadretop" align="center"><b><?php echo "$TITLE";?></b><br><font size="-1"><?php echo "$SUBTITLE";?></font></td>
  <td class="cadretopright" width="128" align="right"><?php include("styles/selectlanguages.php");?></td>
  </tr>
<tr bgcolor="#CCCC66" valign="top">
<td COLSPAN="3" class="cadre">
            <div class="menu"> 
              <font class="menu">
&nbsp;<a href='../'>Home</a> || <a href='index.php'><?php echo $lgMINDEX;?></a> | <a href='detailed.php'><?php echo $lgMDETAILED;?></a> | <a href='readings.php'><?php echo $lgMREAD;?></a>  | <a href='comparison.php'><?php echo $lgMCOMPARISON;?></a> | <a href='dashboard.php'><?php echo $lgMDASH;?></a> | <a href='info.php'><?php echo $lgMINFO;?></a></font>
            </div>
</td></tr>
<tr valign="top"> 
    <td COLSPAN="3" class="cadrebot" bgcolor="#d3dae2">
<!-- #BeginEditable "mainbox" -->
