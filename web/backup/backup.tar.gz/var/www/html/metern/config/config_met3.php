<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### CONFIG FOR METER #3
    
$METNAME3="EV";
$TYPE3='Elect';
$PROD3=0;
$PHASE3=1;
$SKIPMONITORING3=false;
$ID3="EV";
$COMMAND3="/var/www/html/metern/scripts/evwatt.sh";
$UNIT3="Wh";
$PRECI3=0;
$PASSO3=0;    
$COLOR3='3229FF';
$PRICE3=0;
$LID3="EV";
$LIVEPOOL3=1;
$LIVECOMMAND3="/var/www/html/metern/scripts/evwattlive.sh";
$LIVEUNIT3="W";
$EMAIL3="";
$POUKEY3='';
$RPITOK3='';
$WARNCONSOD3=0;
$NORESPM3=false;

$cfgver=1502175480;
?>
