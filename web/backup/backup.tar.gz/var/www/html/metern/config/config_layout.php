<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
 
$GRAPHH=220;
$POWER_MIN=-7000;
$POWER_MAX=7000;
$GRAPH_MET1=1;
$LASTD_MET1=true;
$FILL_MET1=true;
$GRAPH_MET2=1;
$LASTD_MET2=true;
$FILL_MET2=true;
$GRAPH_MET3=1;
$LASTD_MET3=true;
$FILL_MET3=true;
$GRAPH_MET4=1;
$LASTD_MET4=true;
$FILL_MET4=true;

$cfgver=1506503500;
?>