<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### CONFIG FOR METER #1
    
$METNAME1="EVU";
$TYPE1='Elect';
$PROD1=2;
$PHASE1=1;
$SKIPMONITORING1=false;
$ID1="EVU";
$COMMAND1="/var/www/html/metern/scripts/bezug.sh";
$UNIT1="Wh";
$PRECI1=0;
$PASSO1=0;    
$COLOR1='962629';
$PRICE1=0.23;
$LID1="EVU";
$LIVEPOOL1=1;
$LIVECOMMAND1="/var/www/html/metern/scripts/bezuglive.sh";
$LIVEUNIT1="W";
$EMAIL1="";
$POUKEY1='';
$RPITOK1='';
$WARNCONSOD1=15000;
$NORESPM1=false;

$cfgver=1502175480;
?>
