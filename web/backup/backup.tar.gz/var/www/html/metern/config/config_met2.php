<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### CONFIG FOR METER #2
    
$METNAME2="PV";
$TYPE2='Elect';
$PROD2=1;
$PHASE2=1;
$SKIPMONITORING2=false;
$ID2="PV";
$COMMAND2="/var/www/html/metern/scripts/pvwatt.sh";
$UNIT2="Wh";
$PRECI2=0;
$PASSO2=0;    
$COLOR2='00FF1B';
$PRICE2=0;
$LID2="PV";
$LIVEPOOL2=1;
$LIVECOMMAND2="/var/www/html/metern/scripts/pvwattlive.sh";
$LIVEUNIT2="W";
$EMAIL2="";
$POUKEY2='';
$RPITOK2='';
$WARNCONSOD2=0;
$NORESPM2=false;

$cfgver=1502175480;
?>
