<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### CONFIG FOR METER #4
    
$METNAME4="Einspeisung";
$TYPE4='Elect';
$PROD4=0;
$PHASE4=1;
$SKIPMONITORING4=false;
$ID4="Einspeisung";
$COMMAND4="/var/www/html/metern/scripts/einspeisung.sh";
$UNIT4="Wh";
$PRECI4=0;
$PASSO4=0;    
$COLOR4='FFFFFF';
$PRICE4=0;
$LID4="Einspeisung";
$LIVEPOOL4=1;
$LIVECOMMAND4="/var/www/html/metern/scripts/einspeisunglive.sh";
$LIVEUNIT4="W";
$EMAIL4="";
$POUKEY4='';
$RPITOK4='';
$WARNCONSOD4=0;
$NORESPM4=false;

$cfgver=1502175480;
?>
