<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// Those scripts will be called each 5 min

//$output = shell_exec('commnd_relay 1 /dev/boiler > /dev/null 2>/dev/null &');

//exec("php /srv/http/comapps/clearsdm.php");
?>
