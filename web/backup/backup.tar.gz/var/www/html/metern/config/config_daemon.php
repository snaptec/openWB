<?php
if(!defined('checkaccess')){die('Direct access not permitted');}
// Manage com. apps daemon as 'http' user if needed

if (is_null($PID)) { // Stop Daemon
//exec("php /srv/http/comapps/com_daemon.php stop");
} else { //Start
//exec("php /srv/http/comapps/com_daemon.php start");
}
?>
