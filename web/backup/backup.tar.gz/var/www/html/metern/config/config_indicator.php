<?php
if(!defined('checkaccess')){die('Direct access not permitted');}

// ### CONFIG FOR INDICATOR(S)
$NUMIND=0;

?>
