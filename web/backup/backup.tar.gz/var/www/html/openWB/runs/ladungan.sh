#!/bin/bash
echo 1 > /var/www/html/openWB/ramdisk/ladedstatus
