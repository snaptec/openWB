<?php $config = array (
  'lademodus' => '2',
  'sofortll' => '15',
);